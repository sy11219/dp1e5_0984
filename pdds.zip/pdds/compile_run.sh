#!/bin/bash
# ================================================================
#  compile_run.sh – Compilar y ejecutar el Planificador Tasf.B2B
# ================================================================

SRC_DIR="src"
OUT_DIR="out"

echo "=== Compilando... ==="
mkdir -p "$OUT_DIR"

javac -encoding UTF-8 -d "$OUT_DIR" \
  "$SRC_DIR/model/Aeropuerto.java" \
  "$SRC_DIR/model/Vuelo.java" \
  "$SRC_DIR/model/Envio.java" \
  "$SRC_DIR/model/Ruta.java" \
  "$SRC_DIR/model/Solucion.java" \
  "$SRC_DIR/data/DataLoader.java" \
  "$SRC_DIR/algorithm/GestorCapacidad.java" \
  "$SRC_DIR/algorithm/Planificador.java" \
  "$SRC_DIR/algorithm/SimulatedAnnealing.java" \
  "$SRC_DIR/report/ReporteResultados.java" \
  "$SRC_DIR/Main.java"

if [ $? -eq 0 ]; then
  echo "=== Compilación exitosa. Ejecutando... ==="
  java -cp "$OUT_DIR" Main
else
  echo "=== Error de compilación ==="
  exit 1
fi
