import data.DataLoader;
import model.Aeropuerto;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class DebugDataLoader {
    public static void main(String[] args) throws Exception {
        Path p = Paths.get("src/datos/aeropuertos.txt");
        byte[] bytes = Files.readAllBytes(p);
        String texto;
        if (bytes.length >= 2 && bytes[0] == (byte)0xFE && bytes[1] == (byte)0xFF) {
            texto = new String(bytes, StandardCharsets.UTF_16BE);
        } else if (bytes.length >= 2 && bytes[0] == (byte)0xFF && bytes[1] == (byte)0xFE) {
            texto = new String(bytes, StandardCharsets.UTF_16LE);
        } else {
            texto = new String(bytes, StandardCharsets.UTF_8);
        }
        System.out.println("TEXT SAMPLE:");
        System.out.println(texto.substring(0, Math.min(200, texto.length())));
        System.out.println("--- LINES ---");
        int i=0;
        for (String line : texto.split("\\r?\\n")) {
            System.out.printf("%02d: %s%n", ++i, line);
            if (i >= 20) break;
        }
        System.out.println("--- PARSE ---");
        List<Aeropuerto> lista = DataLoader.cargarAeropuertosDesdeArchivo(texto);
        System.out.println("Parsed airports count: " + lista.size());
        for (Aeropuerto a : lista) {
            System.out.println(a.getCodigo() + " " + a.getCiudad() + " " + a.getPais() + " " + a.getContinente() + " " + a.getGmtOffset() + " " + a.getCapacidadMaxima());
        }

        // Direct reflection test on first airport line
        String firstLine = texto.split("\\r?\\n")[3];
        java.lang.reflect.Method m = DataLoader.class.getDeclaredMethod("parsearLineaAeropuerto", String.class, String.class);
        m.setAccessible(true);
        Object parsed = m.invoke(null, firstLine, "SA");
        System.out.println("Reflection parse result: " + parsed);
    }
}
