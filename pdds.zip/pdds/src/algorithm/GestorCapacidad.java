package algorithm;

import model.Aeropuerto;
import model.Ruta;
import model.Solucion;
import model.Vuelo;

import java.util.*;

/**
 * Gestiona la capacidad global de vuelos y aeropuertos.
 *
 * Para una solución dada, registra cuántas maletas ocupa cada vuelo
 * y cuántas maletas están almacenadas en cada aeropuerto en cada momento.
 *
 * IMPORTANTE: Este gestor trabaja sobre "snapshots" de soluciones.
 * La estrategia es:
 *  1. Antes de evaluar una solución, liberar todas las reservas anteriores.
 *  2. Reconstruir las reservas desde cero con la nueva solución.
 *  3. Si una reserva viola capacidad, marcar esa ruta como no válida.
 */
public class GestorCapacidad {

    private final Map<String, Aeropuerto> aeropuertos;
    // vuelo.id → maletas reservadas en ese vuelo
    private final Map<Integer, Integer> reservasVuelo;
    // aeropuerto → maletas actualmente almacenadas (pico máximo simultáneo)
    // Simplificación: contamos las maletas que "pasan" por el aeropuerto
    // en la ventana de su estadía (llegada de un vuelo → salida del siguiente)
    private final Map<String, Integer> ocupacionAeropuerto;

    public GestorCapacidad(Map<String, Aeropuerto> aeropuertos) {
        this.aeropuertos = aeropuertos;
        this.reservasVuelo = new HashMap<>();
        this.ocupacionAeropuerto = new HashMap<>();
    }

    // ---- API principal -------------------------------------------------------

    /**
     * Aplica una solución completa:
     *  - Libera todas las reservas anteriores.
     *  - Intenta reservar capacidad para cada ruta.
     *  - Rutas que no caben quedan marcadas inválidas (no se asignan).
     *
     * @return Lista de índices de rutas que NO pudieron ser asignadas por capacidad.
     */
    public List<Integer> aplicarSolucion(Solucion solucion) {
        // 1. Limpiar reservas anteriores en vuelos
        for (Map.Entry<Integer, Integer> e : reservasVuelo.entrySet()) {
            // No podemos liberar sobre el objeto Vuelo aquí porque ya podría ser otro
            // Usamos el mapa interno únicamente
        }
        reservasVuelo.clear();
        ocupacionAeropuerto.clear();

        // 2. Resetear contadores en objetos Vuelo
        // (Los objetos Vuelo son compartidos; se resetean desde afuera)
        // Esta clase trabaja con copias locales de las reservas para NO mutar los vuelos.

        // Para este gestor, mapeamos vuelo.id → cantidad reservada de forma independiente
        // Construimos un mapa de capacidad disponible por vuelo
        // Obtenemos todos los vuelos únicos de la solución
        Map<Integer, int[]> capDisponibleVuelo = new HashMap<>();
        for (model.Ruta r : solucion.getRutas()) {
            for (Vuelo v : r.getVuelos()) {
                capDisponibleVuelo.putIfAbsent(v.getId(), new int[]{v.getCapacidadMax()});
            }
        }

        // Mapa de ocupación de aeropuertos: aeropuerto → capacidad usada
        Map<String, int[]> capDisponibleAero = new HashMap<>();
        for (Aeropuerto a : aeropuertos.values()) {
            capDisponibleAero.put(a.getCodigo(), new int[]{a.getCapacidadMaxima()});
        }

        List<Integer> fallidas = new ArrayList<>();
        List<model.Ruta> rutas = solucion.getRutas();

        // Ordenar por llegada final (priorizar rutas que llegan antes)
        // para asignar capacidad a los más urgentes primero
        Integer[] indices = new Integer[rutas.size()];
        for (int i = 0; i < indices.length; i++) indices[i] = i;
        Arrays.sort(indices, (a, b) -> {
            int la = rutas.get(a).getLlegadaFinalUTC();
            int lb = rutas.get(b).getLlegadaFinalUTC();
            return Integer.compare(la, lb);
        });

        for (int idx : indices) {
            model.Ruta r = rutas.get(idx);
            if (!r.isValida()) {
                fallidas.add(idx);
                continue;
            }

            int cant = r.getEnvio().getCantidadMaletas();
            boolean ok = true;

            // Verificar capacidad en cada vuelo
            for (Vuelo v : r.getVuelos()) {
                int[] cap = capDisponibleVuelo.get(v.getId());
                if (cap == null || cap[0] < cant) {
                    ok = false;
                    break;
                }
            }

            // Verificar capacidad en el aeropuerto DESTINO (las maletas se almacenan allí)
            // Solo verificamos el destino final y escalas intermedias
            if (ok) {
                for (Vuelo v : r.getVuelos()) {
                    int[] capAero = capDisponibleAero.get(v.getDestino());
                    if (capAero == null || capAero[0] < cant) {
                        ok = false;
                        break;
                    }
                }
            }

            if (ok) {
                // Reservar en vuelos
                for (Vuelo v : r.getVuelos()) {
                    capDisponibleVuelo.get(v.getId())[0] -= cant;
                    reservasVuelo.merge(v.getId(), cant, Integer::sum);
                }
                // Reservar en aeropuerto destino final
                String destFinal = r.getVuelos().get(r.getVuelos().size()-1).getDestino();
                capDisponibleAero.get(destFinal)[0] -= cant;
                ocupacionAeropuerto.merge(destFinal, cant, Integer::sum);
            } else {
                fallidas.add(idx);
            }
        }

        return fallidas;
    }

    /**
     * Verifica si una ruta ADICIONAL puede ser asignada dado el estado actual
     * de las reservas. Útil durante construcción de solución vecina.
     */
    public boolean puedeAsignar(model.Ruta r, Map<Integer, int[]> capVuelos,
                                 Map<String, int[]> capAeros) {
        if (!r.isValida()) return false;
        int cant = r.getEnvio().getCantidadMaletas();
        for (Vuelo v : r.getVuelos()) {
            int[] cap = capVuelos.get(v.getId());
            if (cap == null || cap[0] < cant) return false;
        }
        for (Vuelo v : r.getVuelos()) {
            int[] capA = capAeros.get(v.getDestino());
            if (capA == null || capA[0] < cant) return false;
        }
        return true;
    }

    // ---- Getters -------------------------------------------------------------

    public Map<String, Integer> getOcupacionAeropuertos() {
        return Collections.unmodifiableMap(ocupacionAeropuerto);
    }
}
