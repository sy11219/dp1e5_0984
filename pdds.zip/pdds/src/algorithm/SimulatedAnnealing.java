package algorithm;

import model.*;
 
import java.util.*;
import java.util.stream.Collectors;
 
/**
 * ============================================================
 *  SIMULATED ANNEALING para el Planificador de Rutas Tasf.B2B
 * ============================================================
 *
 * OBJETIVO: Maximizar la cantidad de maletas entregadas a tiempo.
 *
 * PARÁMETROS DE TEMPERATURA:
 *  - T0 (temperatura inicial): alta → acepta casi cualquier vecino.
 *  - Tmin (temperatura mínima): baja → solo acepta mejoras.
 *  - alpha (factor de enfriamiento): T_{k+1} = alpha * T_k
 *  - iteracionesPorTemperatura: cuántos vecinos se evalúan por nivel de T.
 *
 * MOVIMIENTOS (generación de vecinos):
 *  M1 – Reasignar un envío a una ruta alternativa (cambio de vuelos).
 *  M2 – Intercambiar las rutas de dos envíos que comparten algún vuelo
 *        (liberando capacidad para reasignar).
 *  M3 – Eliminar una escala intermedia si la ruta directa también cumple.
 *
 * GESTIÓN DE CAPACIDAD:
 *  Se mantiene un mapa mutable de capacidad (por vuelo y por aeropuerto)
 *  que se actualiza al aceptar un movimiento. Si un movimiento viola
 *  capacidad, se rechaza automáticamente (no hace falta temperatura).
 */
public class SimulatedAnnealing {
 
    // ---- Parámetros por defecto ---------------------------------------------
    private double temperaturaInicial  = 5000.0;
    private double temperaturaMinima   = 0.1;
    private double alpha               = 0.995;   // enfriamiento geométrico
    private int    iteracionesPorTemp  = 50;
    private int    maxIteraciones      = 200_000;  // tope duro
    private int    maxRutasAlternativas= 8;        // rutas a explorar por vecino
 
    private final Planificador planificador;
    private final Random       rnd;
 
    // Estado mutable de capacidad (se clona al inicio y se actualiza en tiempo real)
    private Map<Integer, int[]> capVuelos;
    private Map<String, int[]>  capAeros;
 
    // Estadísticas
    private int iteracionesRealizadas;
    private int mejorasAceptadas;
    private int peoresAceptadas;
    private int rechazados;
 
    public SimulatedAnnealing(Planificador planificador) {
        this.planificador = planificador;
        this.rnd          = new Random(42); // seed fija para reproducibilidad
    }
 
    // ---- Punto de entrada principal -----------------------------------------
 
    /**
     * Ejecuta el SA y devuelve la mejor solución encontrada.
     *
     * @param envios Lista de todos los envíos a planificar.
     */
    public Solucion ejecutar(List<Envio> envios) {
 
        System.out.println("=== SIMULATED ANNEALING – Tasf.B2B ===");
        System.out.printf("Envíos: %d | T0=%.1f | alpha=%.4f | iterMax=%d%n",
                envios.size(), temperaturaInicial, alpha, maxIteraciones);
 
        // 1. Inicializar capacidades frescas
        capVuelos = Planificador.crearCapVuelos(planificador.getVuelos());
        capAeros  = Planificador.crearCapAeros(planificador.getAeropuertos());
 
        // 2. Solución inicial (greedy)
        long t0 = System.currentTimeMillis();
        Solucion actual = planificador.construirSolucionInicial(envios,
                clonarCapVuelos(), clonarCapAeros());
        System.out.printf("Solución inicial: %s%n", actual);
 
        // Aplicar reservas de la solución inicial al estado global
        aplicarSolucionACapacidades(actual);
 
        Solucion mejor = actual;
 
        // 3. Loop principal SA
        double T = temperaturaInicial;
        int    iter = 0;
        iteracionesRealizadas = 0;
        mejorasAceptadas = peoresAceptadas = rechazados = 0;
 
        while (T > temperaturaMinima && iter < maxIteraciones) {
            for (int i = 0; i < iteracionesPorTemp; i++) {
                iter++;
 
                // Generar vecino
                ResultadoMovimiento mov = generarVecino(actual, envios);
                if (mov == null) { rechazados++; continue; }
 
                double delta = mov.solucionVecina.getFitness() - actual.getFitness();
 
                boolean aceptar;
                if (delta >= 0) {
                    // Mejora o igual: siempre aceptar
                    aceptar = true;
                    if (delta > 0) mejorasAceptadas++;
                } else {
                    // Empeora: aceptar con probabilidad Boltzmann
                    double prob = Math.exp(delta / T);
                    aceptar = rnd.nextDouble() < prob;
                    if (aceptar) peoresAceptadas++;
                    else rechazados++;
                }
 
                if (aceptar) {
                    // Actualizar capacidades (deshacer antiguo, aplicar nuevo)
                    revertirMovimiento(mov.rutaAntigua);
                    aplicarMovimiento(mov.rutaNueva);
                    actual = mov.solucionVecina;
 
                    if (actual.getFitness() > mejor.getFitness()) {
                        mejor = actual;
                        System.out.printf("  [iter=%d T=%.2f] Nueva mejor: %s%n",
                                iter, T, mejor);
                    }
                }
 
                iteracionesRealizadas++;
            }
 
            T *= alpha;
        }
 
        long elapsed = System.currentTimeMillis() - t0;
        System.out.println("\n=== RESULTADO FINAL ===");
        System.out.println(mejor);
        System.out.printf("Tiempo: %.2f s | Iteraciones: %d | Mejoras: %d | Peores aceptadas: %d%n",
                elapsed / 1000.0, iteracionesRealizadas, mejorasAceptadas, peoresAceptadas);
 
        return mejor;
    }
 
    // ---- Generación de vecinos -----------------------------------------------
 
    /**
     * Genera un movimiento vecino eligiendo aleatoriamente entre M1, M2, M3.
     */
    private ResultadoMovimiento generarVecino(Solucion actual, List<Envio> todosLosEnvios) {
        int tipo = rnd.nextInt(3);
        switch (tipo) {
            case 0: return movimientoReasignar(actual);
            case 1: return movimientoIntercambiar(actual);
            case 2: return movimientoSimplificar(actual);
            default: return null;
        }
    }
 
    /**
     * M1: Reasigna un envío a una ruta alternativa.
     */
    private ResultadoMovimiento movimientoReasignar(Solucion actual) {
        List<Ruta> rutas = new ArrayList<>(actual.getRutas());
        // Elegir preferentemente un envío no-a-tiempo
        List<Integer> candidatos = new ArrayList<>();
        for (int i = 0; i < rutas.size(); i++) {
            if (!rutas.get(i).isATiempo()) candidatos.add(i);
        }
        if (candidatos.isEmpty()) {
            // Todos a tiempo: elegir uno al azar para explorar
            candidatos.add(rnd.nextInt(rutas.size()));
        }
        int idx = candidatos.get(rnd.nextInt(candidatos.size()));
        Ruta rutaOriginal = rutas.get(idx);
        Envio envio = rutaOriginal.getEnvio();
 
        // Simular capacidades sin la ruta original
        Map<Integer, int[]> capV = clonarCapVuelos();
        Map<String, int[]>  capA = clonarCapAeros();
        liberarRutaEnMapa(rutaOriginal, capV, capA);
 
        // Buscar rutas alternativas
        List<List<Vuelo>> alternativas = planificador.encontrarTodasLasRutas(
                envio, capV, capA, maxRutasAlternativas);
 
        if (alternativas.isEmpty()) return null;
 
        List<Vuelo> nuevosVuelos = alternativas.get(rnd.nextInt(alternativas.size()));
        Ruta nuevaRuta = new Ruta(envio, nuevosVuelos);
 
        // Construir solución vecina
        List<Ruta> nuevasRutas = new ArrayList<>(rutas);
        nuevasRutas.set(idx, nuevaRuta);
        Solucion vecina = new Solucion(nuevasRutas);
 
        return new ResultadoMovimiento(vecina, rutaOriginal, nuevaRuta);
    }
 
    /**
     * M2: Intercambia las rutas de dos envíos que comparten un vuelo,
     * liberando capacidad para reasignar ambos.
     */
    private ResultadoMovimiento movimientoIntercambiar(Solucion actual) {
        List<Ruta> rutas = new ArrayList<>(actual.getRutas());
        if (rutas.size() < 2) return null;
 
        // Elegir dos índices aleatorios
        int i = rnd.nextInt(rutas.size());
        int j;
        do { j = rnd.nextInt(rutas.size()); } while (j == i);
 
        Ruta rutaI = rutas.get(i);
        Ruta rutaJ = rutas.get(j);
 
        // Solo tiene sentido intercambiar si alguno no está a tiempo
        if (rutaI.isATiempo() && rutaJ.isATiempo()) {
            if (rnd.nextDouble() > 0.1) return null; // 90% de chance de no hacerlo
        }
 
        Map<Integer, int[]> capV = clonarCapVuelos();
        Map<String, int[]>  capA = clonarCapAeros();
        liberarRutaEnMapa(rutaI, capV, capA);
        liberarRutaEnMapa(rutaJ, capV, capA);
 
        // Reasignar ambos (el que tiene límite más urgente primero)
        Envio envioI = rutaI.getEnvio();
        Envio envioJ = rutaJ.getEnvio();
 
        List<Vuelo> nuevosI = planificador.encontrarMejorRuta(envioI, capV, capA);
        if (nuevosI != null) {
            int cant = envioI.getCantidadMaletas();
            for (Vuelo v : nuevosI) capV.get(v.getId())[0] -= cant;
            String df = nuevosI.get(nuevosI.size()-1).getDestino();
            capA.get(df)[0] -= cant;
        }
 
        List<Vuelo> nuevosJ = planificador.encontrarMejorRuta(envioJ, capV, capA);
 
        Ruta nuevaI = new Ruta(envioI, nuevosI != null ? nuevosI : Collections.emptyList());
        Ruta nuevaJ = new Ruta(envioJ, nuevosJ != null ? nuevosJ : Collections.emptyList());
 
        List<Ruta> nuevasRutas = new ArrayList<>(rutas);
        nuevasRutas.set(i, nuevaI);
        nuevasRutas.set(j, nuevaJ);
        Solucion vecina = new Solucion(nuevasRutas);
 
        // Para revertir/aplicar, elegimos la ruta que cambió más (i)
        return new ResultadoMovimiento(vecina, rutaI, nuevaI);
    }
 
    /**
     * M3: Simplifica una ruta eliminando una escala si la ruta más directa funciona.
     */
    private ResultadoMovimiento movimientoSimplificar(Solucion actual) {
        List<Ruta> rutas = new ArrayList<>(actual.getRutas());
        // Buscar rutas con más de un vuelo
        List<Integer> candidatos = new ArrayList<>();
        for (int i = 0; i < rutas.size(); i++) {
            if (rutas.get(i).getVuelos().size() > 1) candidatos.add(i);
        }
        if (candidatos.isEmpty()) return null;
 
        int idx = candidatos.get(rnd.nextInt(candidatos.size()));
        Ruta rutaOriginal = rutas.get(idx);
        Envio envio = rutaOriginal.getEnvio();
 
        Map<Integer, int[]> capV = clonarCapVuelos();
        Map<String, int[]>  capA = clonarCapAeros();
        liberarRutaEnMapa(rutaOriginal, capV, capA);
 
        // Buscar ruta directa (greedy)
        List<Vuelo> directa = planificador.encontrarMejorRuta(envio, capV, capA);
        if (directa == null || directa.isEmpty()) return null;
 
        Ruta nuevaRuta = new Ruta(envio, directa);
        if (!nuevaRuta.isATiempo()) return null;
 
        List<Ruta> nuevasRutas = new ArrayList<>(rutas);
        nuevasRutas.set(idx, nuevaRuta);
        Solucion vecina = new Solucion(nuevasRutas);
 
        return new ResultadoMovimiento(vecina, rutaOriginal, nuevaRuta);
    }
 
    // ---- Gestión de capacidades locales -------------------------------------
 
    private void aplicarSolucionACapacidades(Solucion s) {
        // Reiniciar capacidades
        capVuelos = Planificador.crearCapVuelos(planificador.getVuelos());
        capAeros  = Planificador.crearCapAeros(planificador.getAeropuertos());
 
        for (Ruta r : s.getRutas()) {
            if (!r.isValida() || r.getVuelos().isEmpty()) continue;
            int cant = r.getEnvio().getCantidadMaletas();
            for (Vuelo v : r.getVuelos()) {
                if (capVuelos.containsKey(v.getId()))
                    capVuelos.get(v.getId())[0] = Math.max(0, capVuelos.get(v.getId())[0] - cant);
            }
            String destFinal = r.getVuelos().get(r.getVuelos().size()-1).getDestino();
            if (capAeros.containsKey(destFinal))
                capAeros.get(destFinal)[0] = Math.max(0, capAeros.get(destFinal)[0] - cant);
        }
    }
 
    private void revertirMovimiento(Ruta rutaAntigua) {
        if (rutaAntigua == null || !rutaAntigua.isValida()) return;
        int cant = rutaAntigua.getEnvio().getCantidadMaletas();
        for (Vuelo v : rutaAntigua.getVuelos()) {
            if (capVuelos.containsKey(v.getId()))
                capVuelos.get(v.getId())[0] += cant;
        }
        if (!rutaAntigua.getVuelos().isEmpty()) {
            String df = rutaAntigua.getVuelos().get(rutaAntigua.getVuelos().size()-1).getDestino();
            if (capAeros.containsKey(df)) capAeros.get(df)[0] += cant;
        }
    }
 
    private void aplicarMovimiento(Ruta rutaNueva) {
        if (rutaNueva == null || !rutaNueva.isValida()) return;
        int cant = rutaNueva.getEnvio().getCantidadMaletas();
        for (Vuelo v : rutaNueva.getVuelos()) {
            if (capVuelos.containsKey(v.getId()))
                capVuelos.get(v.getId())[0] = Math.max(0, capVuelos.get(v.getId())[0] - cant);
        }
        if (!rutaNueva.getVuelos().isEmpty()) {
            String df = rutaNueva.getVuelos().get(rutaNueva.getVuelos().size()-1).getDestino();
            if (capAeros.containsKey(df))
                capAeros.get(df)[0] = Math.max(0, capAeros.get(df)[0] - cant);
        }
    }
 
    private void liberarRutaEnMapa(Ruta ruta, Map<Integer, int[]> capV, Map<String, int[]> capA) {
        if (ruta == null || !ruta.isValida()) return;
        int cant = ruta.getEnvio().getCantidadMaletas();
        for (Vuelo v : ruta.getVuelos()) {
            if (capV.containsKey(v.getId())) capV.get(v.getId())[0] += cant;
        }
        if (!ruta.getVuelos().isEmpty()) {
            String df = ruta.getVuelos().get(ruta.getVuelos().size()-1).getDestino();
            if (capA.containsKey(df)) capA.get(df)[0] += cant;
        }
    }
 
    // ---- Clonado de mapas de capacidad ---------------------------------------
 
    private Map<Integer, int[]> clonarCapVuelos() {
        Map<Integer, int[]> clon = new HashMap<>();
        capVuelos.forEach((k, v) -> clon.put(k, new int[]{v[0]}));
        return clon;
    }
 
    private Map<String, int[]> clonarCapAeros() {
        Map<String, int[]> clon = new HashMap<>();
        capAeros.forEach((k, v) -> clon.put(k, new int[]{v[0]}));
        return clon;
    }
 
    // ---- Configuración -------------------------------------------------------
 
    public SimulatedAnnealing setTemperaturaInicial(double t)   { this.temperaturaInicial = t;   return this; }
    public SimulatedAnnealing setTemperaturaMinima(double t)    { this.temperaturaMinima = t;    return this; }
    public SimulatedAnnealing setAlpha(double a)                { this.alpha = a;                return this; }
    public SimulatedAnnealing setIteracionesPorTemp(int n)      { this.iteracionesPorTemp = n;   return this; }
    public SimulatedAnnealing setMaxIteraciones(int n)          { this.maxIteraciones = n;       return this; }
    public SimulatedAnnealing setMaxRutasAlternativas(int n)    { this.maxRutasAlternativas = n; return this; }
 
    // ---- Clase interna -------------------------------------------------------
 
    private static class ResultadoMovimiento {
        final Solucion solucionVecina;
        final Ruta     rutaAntigua;
        final Ruta     rutaNueva;
 
        ResultadoMovimiento(Solucion s, Ruta antigua, Ruta nueva) {
            this.solucionVecina = s;
            this.rutaAntigua    = antigua;
            this.rutaNueva      = nueva;
        }
    }
}