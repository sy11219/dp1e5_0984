package algorithm;

import model.*;
 
import java.util.*;
import java.util.stream.Collectors;
 
/**
 * Planificador: construye soluciones iniciales y vecinas.
 *
 * Búsqueda de rutas: BFS/Greedy sobre el grafo de vuelos,
 * respetando:
 *  - Tiempo de espera mínimo de conexión (10 min)
 *  - Primer embarque ≥ registro + 10 min
 *  - Sin ciclos (no repetir aeropuertos)
 *  - Dentro del límite de tiempo del envío
 */
public class Planificador {
 
    // Máximo de escalas permitidas en una ruta (evita explosión combinatoria)
    private static final int MAX_ESCALAS = 4;
 
    private final Map<String, Aeropuerto>       aeropuertos;
    private final List<Vuelo>                   vuelos;
    // Índice: origen → lista de vuelos desde ese origen (ordenados por salida)
    private final Map<String, List<Vuelo>>      vuelosPorOrigen;
 
    public Planificador(Map<String, Aeropuerto> aeropuertos, List<Vuelo> vuelos) {
        this.aeropuertos = aeropuertos;
        this.vuelos      = vuelos;
        this.vuelosPorOrigen = new HashMap<>();
        for (Vuelo v : vuelos) {
            vuelosPorOrigen.computeIfAbsent(v.getOrigen(), k -> new ArrayList<>()).add(v);
        }
        // Ordenar por hora de salida UTC
        vuelosPorOrigen.values().forEach(lista ->
                lista.sort(Comparator.comparingInt(Vuelo::getSalidaUTC)));
    }
 
    // ---- Construcción de solución inicial ------------------------------------
 
    /**
     * Construye una solución greedy: para cada envío, encuentra la ruta
     * más rápida (Dijkstra por tiempo de llegada) que cumpla el plazo.
     */
    public Solucion construirSolucionInicial(List<Envio> envios,
                                              Map<Integer, int[]> capVuelos,
                                              Map<String, int[]> capAeros) {
        List<Ruta> rutas = new ArrayList<>();
 
        // Ordenar envíos por urgencia (límite más cercano primero)
        List<Envio> ordenados = envios.stream()
                .sorted(Comparator.comparingInt(Envio::getLimiteEntregaUTC))
                .collect(Collectors.toList());
 
        for (Envio envio : ordenados) {
            List<Vuelo> mejorRuta = encontrarMejorRuta(envio, capVuelos, capAeros);
            Ruta ruta = new Ruta(envio, mejorRuta != null ? mejorRuta : Collections.emptyList());
            rutas.add(ruta);
 
            // Si la ruta es válida, reservar capacidad
            if (mejorRuta != null && ruta.isValida()) {
                int cant = envio.getCantidadMaletas();
                for (Vuelo v : mejorRuta) {
                    if (capVuelos.containsKey(v.getId()))
                        capVuelos.get(v.getId())[0] -= cant;
                }
                String destFinal = mejorRuta.get(mejorRuta.size()-1).getDestino();
                if (capAeros.containsKey(destFinal))
                    capAeros.get(destFinal)[0] -= cant;
            }
        }
 
        return new Solucion(rutas);
    }
 
    /**
     * Dijkstra adaptado: encuentra la ruta de vuelos con menor tiempo de llegada
     * que cumpla el plazo del envío, respetando capacidades.
     *
     * @return Lista de vuelos (ruta), o null si no existe ruta válida.
     */
    public List<Vuelo> encontrarMejorRuta(Envio envio,
                                           Map<Integer, int[]> capVuelos,
                                           Map<String, int[]> capAeros) {
        String orig  = envio.getAeropuertoOrigen();
        String dest  = envio.getAeropuertoDestino();
        int    limite = envio.getLimiteEntregaUTC();
        int    cant   = envio.getCantidadMaletas();
        int    tReady = envio.getPrimeroSalidaUTC(); // registro + 10
 
        if (orig.equals(dest)) return Collections.emptyList();
 
        // Estado: [tiempo_disponible_en_este_nodo, aeropuerto_actual, ruta_hasta_aqui]
        // Usamos PriorityQueue por tiempo_disponible (menor primero)
        PriorityQueue<Estado> pq = new PriorityQueue<>(
                Comparator.comparingInt(e -> e.tiempoDisponible));
 
        pq.offer(new Estado(tReady, orig, new ArrayList<>(), new HashSet<>(Set.of(orig))));
 
        List<Vuelo> mejorRuta = null;
        int mejorLlegada = Integer.MAX_VALUE;
 
        while (!pq.isEmpty()) {
            Estado actual = pq.poll();
 
            // Poda: si ya tenemos una solución mejor, descartar
            if (actual.tiempoDisponible >= mejorLlegada) continue;
            if (actual.vuelos.size() >= MAX_ESCALAS) continue;
 
            // Obtener vuelos desde aeropuerto actual
            List<Vuelo> candidatos = vuelosPorOrigen.getOrDefault(actual.aeropuerto, Collections.emptyList());
 
            for (Vuelo v : candidatos) {
                // El vuelo debe salir después de que las maletas estén listas
                if (v.getSalidaUTC() < actual.tiempoDisponible) continue;
                // Poda por tiempo: si ya llegamos tarde, saltar
                if (v.getLlegadaUTC() > limite) continue;
                // No repetir aeropuertos
                if (actual.visitados.contains(v.getDestino())) continue;
                // Verificar capacidad en vuelo
                if (capVuelos.containsKey(v.getId()) && capVuelos.get(v.getId())[0] < cant) continue;
                // Verificar capacidad en aeropuerto destino
                if (capAeros.containsKey(v.getDestino()) && capAeros.get(v.getDestino())[0] < cant) continue;
 
                List<Vuelo> nuevaRuta = new ArrayList<>(actual.vuelos);
                nuevaRuta.add(v);
 
                if (v.getDestino().equals(dest)) {
                    // Llegamos al destino
                    if (v.getLlegadaUTC() < mejorLlegada) {
                        mejorLlegada = v.getLlegadaUTC();
                        mejorRuta = nuevaRuta;
                    }
                } else {
                    // Seguir explorando (conexión mínima: llegada + 10)
                    Set<String> nuevosVisitados = new HashSet<>(actual.visitados);
                    nuevosVisitados.add(v.getDestino());
                    pq.offer(new Estado(v.getLlegadaUTC() + 10, v.getDestino(),
                            nuevaRuta, nuevosVisitados));
                }
            }
        }
 
        return mejorRuta;
    }
 
    /**
     * Encuentra TODAS las rutas válidas para un envío (hasta un límite).
     * Útil para el SA al generar vecinos.
     */
    public List<List<Vuelo>> encontrarTodasLasRutas(Envio envio,
                                                      Map<Integer, int[]> capVuelos,
                                                      Map<String, int[]> capAeros,
                                                      int maxRutas) {
        String orig  = envio.getAeropuertoOrigen();
        String dest  = envio.getAeropuertoDestino();
        int    limite = envio.getLimiteEntregaUTC();
        int    cant   = envio.getCantidadMaletas();
        int    tReady = envio.getPrimeroSalidaUTC();
 
        List<List<Vuelo>> resultado = new ArrayList<>();
        if (orig.equals(dest)) return resultado;
 
        Queue<Estado> queue = new LinkedList<>();
        queue.offer(new Estado(tReady, orig, new ArrayList<>(), new HashSet<>(Set.of(orig))));
 
        while (!queue.isEmpty() && resultado.size() < maxRutas) {
            Estado actual = queue.poll();
            if (actual.vuelos.size() >= MAX_ESCALAS) continue;
 
            List<Vuelo> candidatos = vuelosPorOrigen.getOrDefault(actual.aeropuerto, Collections.emptyList());
 
            for (Vuelo v : candidatos) {
                if (v.getSalidaUTC() < actual.tiempoDisponible) continue;
                if (v.getLlegadaUTC() > limite) continue;
                if (actual.visitados.contains(v.getDestino())) continue;
                if (capVuelos.containsKey(v.getId()) && capVuelos.get(v.getId())[0] < cant) continue;
                if (capAeros.containsKey(v.getDestino()) && capAeros.get(v.getDestino())[0] < cant) continue;
 
                List<Vuelo> nuevaRuta = new ArrayList<>(actual.vuelos);
                nuevaRuta.add(v);
 
                if (v.getDestino().equals(dest)) {
                    resultado.add(nuevaRuta);
                    if (resultado.size() >= maxRutas) break;
                } else {
                    Set<String> nuevosVisitados = new HashSet<>(actual.visitados);
                    nuevosVisitados.add(v.getDestino());
                    queue.offer(new Estado(v.getLlegadaUTC() + 10, v.getDestino(),
                            nuevaRuta, nuevosVisitados));
                }
            }
        }
 
        return resultado;
    }
 
    // ---- Clase interna Estado ------------------------------------------------
 
    private static class Estado {
        final int          tiempoDisponible;
        final String       aeropuerto;
        final List<Vuelo>  vuelos;
        final Set<String>  visitados;
 
        Estado(int t, String aero, List<Vuelo> vuelos, Set<String> visitados) {
            this.tiempoDisponible = t;
            this.aeropuerto       = aero;
            this.vuelos           = vuelos;
            this.visitados        = visitados;
        }
    }
 
    // ---- Getters -------------------------------------------------------------
 
    public Map<String, Aeropuerto> getAeropuertos() { return aeropuertos; }
    public List<Vuelo>             getVuelos()       { return vuelos; }
 
    /** Inicializa mapas de capacidad frescos para todos los vuelos y aeropuertos. */
    public static Map<Integer, int[]> crearCapVuelos(List<Vuelo> vuelos) {
        Map<Integer, int[]> cap = new HashMap<>();
        for (Vuelo v : vuelos) cap.put(v.getId(), new int[]{v.getCapacidadMax()});
        return cap;
    }
 
    public static Map<String, int[]> crearCapAeros(Map<String, Aeropuerto> aeropuertos) {
        Map<String, int[]> cap = new HashMap<>();
        for (Aeropuerto a : aeropuertos.values())
            cap.put(a.getCodigo(), new int[]{a.getCapacidadMaxima()});
        return cap;
    }
}