package report;

import model.*;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Genera reportes de la solución final: resumen global, detalle por envío
 * y semáforo de ocupación de aeropuertos.
 */
public class ReporteResultados {

    // Rangos para semáforo (parametrizables)
    private double umbralVerde  = 0.60;  // < 60% ocupación → verde
    private double umbralAmbar  = 0.85;  // 60-85% → ámbar, >85% → rojo

    public ReporteResultados() {}

    public ReporteResultados(double umbralVerde, double umbralAmbar) {
        this.umbralVerde = umbralVerde;
        this.umbralAmbar = umbralAmbar;
    }

    // ---- Reporte principal ---------------------------------------------------

    public void imprimirReporte(Solucion solucion, Map<String, Aeropuerto> aeropuertos) {
        System.out.println("\n" + "=".repeat(80));
        System.out.println("  REPORTE FINAL DE PLANIFICACIÓN – Tasf.B2B");
        System.out.println("=".repeat(80));

        // Resumen global
        System.out.printf("%nRESUMEN GLOBAL:%n");
        System.out.printf("  Envíos totales     : %d%n", solucion.getTotalEnvios());
        System.out.printf("  Envíos a tiempo    : %d  (%.1f%%)%n",
                solucion.getEnviosATiempo(),
                100.0 * solucion.getEnviosATiempo() / Math.max(1, solucion.getTotalEnvios()));
        System.out.printf("  Maletas totales    : %d%n", solucion.getTotalMaletas());
        System.out.printf("  Maletas a tiempo   : %d  (%.1f%%)%n",
                solucion.getMaletasATiempo(), solucion.getPorcentajeATiempo());

        // Detalle por envío
        System.out.printf("%nDETALLE POR ENVÍO:%n");
        System.out.printf("%-15s %-6s %-6s %-8s %-8s %-8s %s%n",
                "ID","ORIG","DEST","MALETAS","LÍMITE","LLEGADA","ESTADO");
        System.out.println("-".repeat(80));

        for (Ruta r : solucion.getRutas()) {
            Envio e = r.getEnvio();
            String llegada = r.isValida()
                    ? Vuelo.minutosAHora(r.getLlegadaFinalUTC())
                    : "N/A";
            String estado = r.isATiempo() ? "✓ A TIEMPO" :
                           (r.isValida() ? "✗ TARDE" : "✗ SIN RUTA");
            System.out.printf("%-15s %-6s %-6s %-8d %-8s %-8s %s%n",
                    e.getId(),
                    e.getAeropuertoOrigen(),
                    e.getAeropuertoDestino(),
                    e.getCantidadMaletas(),
                    Vuelo.minutosAHora(e.getLimiteEntregaUTC()),
                    llegada,
                    estado);

            // Imprimir la ruta de vuelos
            if (!r.getVuelos().isEmpty()) {
                System.out.print("               Ruta: " + e.getAeropuertoOrigen());
                for (Vuelo v : r.getVuelos()) {
                    System.out.printf(" -[V%03d sal=%s]→ %s",
                            v.getId(),
                            Vuelo.minutosAHora(v.getSalidaUTC()),
                            v.getDestino());
                }
                System.out.println();
            }
        }

        // Semáforo de aeropuertos
        System.out.printf("%nSEMÁFORO DE OCUPACIÓN DE AEROPUERTOS:%n");
        System.out.printf("  (Verde < %.0f%% | Ámbar %.0f-%.0f%% | Rojo > %.0f%%)%n",
                umbralVerde*100, umbralVerde*100, umbralAmbar*100, umbralAmbar*100);
        System.out.printf("%-6s %-20s %-8s %-8s %-8s %s%n",
                "ICAO","Ciudad","Capacidad","Uso","% Uso","Semáforo");
        System.out.println("-".repeat(65));

        // Calcular ocupación real desde la solución
        Map<String, Integer> ocupacion = calcularOcupacion(solucion);

        aeropuertos.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .forEach(entry -> {
                    Aeropuerto a = entry.getValue();
                    int usoMaletas = ocupacion.getOrDefault(a.getCodigo(), 0);
                    double pct = (double) usoMaletas / a.getCapacidadMaxima();
                    String semaforo = semaforo(pct);
                    System.out.printf("%-6s %-20s %-8d %-8d %-8.1f %s%n",
                            a.getCodigo(), a.getCiudad(),
                            a.getCapacidadMaxima(), usoMaletas, pct*100, semaforo);
                });

        // Envíos sin ruta
        List<Ruta> sinRuta = solucion.getRutas().stream()
                .filter(r -> !r.isValida())
                .collect(Collectors.toList());
        if (!sinRuta.isEmpty()) {
            System.out.printf("%nENVÍOS SIN RUTA VÁLIDA (%d):%n", sinRuta.size());
            for (Ruta r : sinRuta) {
                System.out.printf("  %s → %s (%d maletas, límite %s)%n",
                        r.getEnvio().getId(),
                        r.getEnvio().getAeropuertoDestino(),
                        r.getEnvio().getCantidadMaletas(),
                        Vuelo.minutosAHora(r.getEnvio().getLimiteEntregaUTC()));
            }
        }

        System.out.println("\n" + "=".repeat(80));
    }

    // ---- Semáforo ------------------------------------------------------------

    private String semaforo(double porcentaje) {
        if (porcentaje < umbralVerde)  return "🟢 VERDE";
        if (porcentaje < umbralAmbar)  return "🟡 ÁMBAR";
        return "🔴  ROJO ";
    }

    // ---- Cálculo de ocupación ------------------------------------------------

    private Map<String, Integer> calcularOcupacion(Solucion solucion) {
        Map<String, Integer> ocu = new HashMap<>();
        for (Ruta r : solucion.getRutas()) {
            if (!r.isValida() || r.getVuelos().isEmpty()) continue;
            String destFinal = r.getVuelos().get(r.getVuelos().size()-1).getDestino();
            ocu.merge(destFinal, r.getEnvio().getCantidadMaletas(), Integer::sum);
        }
        return ocu;
    }

    // ---- Plan de viaje por envío --------------------------------------------

    public void imprimirPlanViaje(Ruta ruta) {
        Envio e = ruta.getEnvio();
        System.out.printf("%nPLAN DE VIAJE – Envío %s%n", e.getId());
        System.out.printf("  Cliente  : %s%n", e.getIdCliente());
        System.out.printf("  Origen   : %s  |  Destino: %s%n",
                e.getAeropuertoOrigen(), e.getAeropuertoDestino());
        System.out.printf("  Maletas  : %d%n", e.getCantidadMaletas());
        System.out.printf("  Registro : %s%n", Vuelo.minutosAHora(e.getRegistroUTC()));
        System.out.printf("  Límite   : %s%n", Vuelo.minutosAHora(e.getLimiteEntregaUTC()));

        if (ruta.getVuelos().isEmpty()) {
            System.out.println("  *** Sin ruta asignada ***");
            return;
        }

        System.out.println("  Etapas:");
        int paso = 1;
        for (Vuelo v : ruta.getVuelos()) {
            System.out.printf("    %d. V%03d: %s (sal %s) → %s (lle %s)%n",
                    paso++, v.getId(),
                    v.getOrigen(), Vuelo.minutosAHora(v.getSalidaUTC()),
                    v.getDestino(), Vuelo.minutosAHora(v.getLlegadaUTC()));
        }
        System.out.printf("  Llegada final: %s  [%s]%n",
                Vuelo.minutosAHora(ruta.getLlegadaFinalUTC()),
                ruta.isATiempo() ? "A TIEMPO ✓" : "TARDÍO ✗");
    }
}
