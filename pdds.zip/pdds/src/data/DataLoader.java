package data;

import model.Aeropuerto;
import model.Envio;
import model.Vuelo;
 
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
 
/**
 * Carga y parsea los datos de aeropuertos, vuelos y envíos.
 *
 * ESTRUCTURA DE CARPETA ESPERADA:
 *   /src/datos/
 *     aeropuertos.txt      formato: por secciones (America del Sur, Europa, Asia)
 *     vuelos.txt           formato: ORIG-DEST-HH:MM-HH:MM-CCCC
 *     envios/
 *       _envios_SKBO.txt    archivos de envíos por aeropuerto origen
 *       _envios_SEQM.txt
 *       ...
 */
public class DataLoader {
 
    private static final Map<String, String> CONTINENTE_MAP = new HashMap<>();
 
    static {
        for (String c : new String[]{"SKBO","SEQM","SVMI","SBBR","SPIM","SLLP","SCEL","SABE","SGAS","SUAA"})
            CONTINENTE_MAP.put(c, "SA");
        for (String c : new String[]{"LATI","EDDI","LOWW","EBCI","UMMS","LBSF","LKPR","LDZA","EKCH","EHAM"})
            CONTINENTE_MAP.put(c, "EU");
        for (String c : new String[]{"VIDP","OSDI","OERK","OMDB","OAKB","OOMS","OYSN","OPKC","UBBB","OJAI"})
            CONTINENTE_MAP.put(c, "AS");
    }
 
    // =========================================================================
    //  CARGA DESDE CARPETA (punto de entrada principal)
    // =========================================================================
 
    /**
     * Carga todo el sistema desde una carpeta raiz.
     *
     * @param carpeta        Ruta absoluta o relativa a la carpeta de datos
     * @param diasSimulacion Numero de dias a simular (los vuelos se replican)
     * @return CargaCompleta con aeropuertos, vuelos y envios
     */
    public static CargaCompleta cargarDesde(String carpeta, int diasSimulacion) throws IOException {
        Path raiz = Paths.get(carpeta).toAbsolutePath();
        if (!Files.isDirectory(raiz))
            throw new IOException("La ruta no es una carpeta valida: " + raiz);
 
        // 1. Aeropuertos desde aeropuertos.txt
        Path archivoAeropuertos = raiz.resolve("aeropuertos.txt");
        if (!Files.exists(archivoAeropuertos))
            throw new IOException("No se encontro aeropuertos.txt en: " + raiz);
        String textoAeropuertos = leerTexto(archivoAeropuertos);
        Map<String, Aeropuerto> aeropuertos = new LinkedHashMap<>();
        for (Aeropuerto a : cargarAeropuertosDesdeArchivo(textoAeropuertos)) aeropuertos.put(a.getCodigo(), a);
        System.out.printf("[DataLoader] Aeropuertos: %d%n", aeropuertos.size());
 
        // 2. Vuelos desde vuelos.txt
        Path archivoVuelos = raiz.resolve("vuelos.txt");
        if (!Files.exists(archivoVuelos))
            throw new IOException("No se encontro vuelos.txt en: " + raiz);
        String textoVuelos = leerTexto(archivoVuelos);
        List<Vuelo> vuelos = cargarVuelos(textoVuelos, aeropuertos, diasSimulacion);
        System.out.printf("[DataLoader] Vuelos: %d (x%d dias)%n", vuelos.size(), diasSimulacion);
 
        // 3. Envios desde carpeta envios/
        List<Envio> todosEnvios = new ArrayList<>();
        Path carpetaEnvios = raiz.resolve("envios");
        if (!Files.exists(carpetaEnvios) || !Files.isDirectory(carpetaEnvios)) {
            throw new IOException("No se encontro la carpeta de envios en: " + carpetaEnvios);
        }
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(carpetaEnvios, "_envios_*.txt")) {
            boolean encontrado = false;
            for (Path p : stream) {
                encontrado = true;
                String nombre = p.getFileName().toString();
                // _envios_SKBO.txt o _envios_SKBO_.txt -> SKBO
                String codigo = nombre.replaceAll("^_envios_", "")
                                     .replaceAll("_?\\.txt$", "")
                                     .trim().toUpperCase();
                if (!aeropuertos.containsKey(codigo)) {
                    System.out.printf("[DataLoader] AVISO: codigo '%s' no reconocido (%s), omitido.%n",
                            codigo, nombre);
                    continue;
                }
                String texto = leerTexto(p);
                List<Envio> parcial = cargarEnvios(texto, codigo, aeropuertos);
                todosEnvios.addAll(parcial);
                System.out.printf("[DataLoader] Envios %s: %d%n", codigo, parcial.size());
            }
            if (!encontrado) {
                System.out.printf("[DataLoader] AVISO: no se encontraron archivos _envios_*.txt en %s%n", carpetaEnvios);
            }
        }
        System.out.printf("[DataLoader] Total envios: %d%n", todosEnvios.size());
 
        return new CargaCompleta(aeropuertos, vuelos, todosEnvios);
    }
 
    // =========================================================================
    //  PARSEO DE VUELOS
    // =========================================================================
 
    /**
     * Parsea vuelos desde texto multilínea.
     * Formato: ORIG-DEST-HH:MM-HH:MM-CCCC (horas locales; se convierten a UTC)
     * Las lineas que comienzan con # son comentarios.
     */
    public static List<Vuelo> cargarVuelos(String texto,
                                            Map<String, Aeropuerto> aeropuertos,
                                            int diasSimulacion) {
        List<Vuelo> lista = new ArrayList<>();
        for (String linea : texto.split("\\n")) {
            linea = linea.trim();
            if (linea.isEmpty() || linea.startsWith("#")) continue;
 
            String[] p = linea.split("-");
            if (p.length < 5) continue;
 
            String orig = p[0].trim();
            String dest = p[1].trim();
            String[] sal = p[2].split(":");
            String[] lle = p[3].split(":");
            if (sal.length < 2 || lle.length < 2) continue;
 
            int capacidad;
            try { capacidad = Integer.parseInt(p[4].trim()); }
            catch (NumberFormatException e) { continue; }
 
            Aeropuerto aOrig = aeropuertos.get(orig);
            Aeropuerto aDest = aeropuertos.get(dest);
            if (aOrig == null || aDest == null) continue;
 
            int salLocal = Integer.parseInt(sal[0].trim()) * 60 + Integer.parseInt(sal[1].trim());
            int lleLocal = Integer.parseInt(lle[0].trim()) * 60 + Integer.parseInt(lle[1].trim());
 
            // Convertir a UTC (hora local - offset_gmt_en_minutos)
            int salUTC = salLocal - aOrig.getGmtOffset();
            int lleUTC = lleLocal - aDest.getGmtOffset();
            if (lleUTC <= salUTC) lleUTC += 1440; // cruza medianoche UTC
 
            // Normalizar salUTC a [0, 1440)
            salUTC = ((salUTC % 1440) + 1440) % 1440;
 
            for (int dia = 0; dia < diasSimulacion; dia++) {
                int off = dia * 1440;
                lista.add(new Vuelo(orig, dest, salUTC + off, lleUTC + off, capacidad));
            }
        }
        lista.sort(Comparator.comparingInt(Vuelo::getSalidaUTC));
        return lista;
    }
 
    // =========================================================================
    //  PARSEO DE ENVIOS
    // =========================================================================
 
    /**
     * Parsea envios desde texto multilínea.
     * Formato: id-aaaammdd-hh-mm-dest-###-IdCliente
     * El tiempo de registro se mapea a minutos UTC desde el dia base 20260102.
     */
    public static List<Envio> cargarEnvios(String texto,
                                            String codigoOrigen,
                                            Map<String, Aeropuerto> aeropuertos) {
        List<Envio> lista = new ArrayList<>();
        for (String linea : texto.split("\\n")) {
            linea = linea.trim();
            if (linea.isEmpty() || linea.startsWith("#")) continue;
 
            String[] p = linea.split("-");
            if (p.length < 7) continue;
 
            String id      = p[0].trim();
            String fechaStr= p[1].trim();
            int hh, mm, cantidad;
            try {
                hh       = Integer.parseInt(p[2].trim());
                mm       = Integer.parseInt(p[3].trim());
                cantidad = Integer.parseInt(p[5].trim());
            } catch (NumberFormatException e) { continue; }
 
            String dest    = p[4].trim().toUpperCase();
            String cliente = p[6].trim();
 
            if (fechaStr.length() < 8) continue;
            int anio = Integer.parseInt(fechaStr.substring(0, 4));
            int mes  = Integer.parseInt(fechaStr.substring(4, 6));
            int dia  = Integer.parseInt(fechaStr.substring(6, 8));
 
            Aeropuerto aOrig = aeropuertos.get(codigoOrigen);
            int gmtOff = (aOrig != null) ? aOrig.getGmtOffset() : 0;
            int minUTC = hh * 60 + mm - gmtOff;
 
            int diasBase   = diasDesde20260102(anio, mes, dia);
            int registroUTC = Math.max(0, diasBase * 1440 + minUTC);
 
            Aeropuerto aDest = aeropuertos.get(dest);
            boolean mismoCont = aOrig != null && aDest != null
                    && aOrig.getContinente().equals(aDest.getContinente());
 
            lista.add(new Envio(id, codigoOrigen, registroUTC, dest, cantidad, cliente, mismoCont));
        }
        lista.sort(Comparator.comparingInt(Envio::getRegistroUTC));
        return lista;
    }
 
    // =========================================================================
    //  PARSEO DE AEROPUERTOS
    // =========================================================================
 
    /**
     * Parsea aeropuertos desde texto multilínea.
     * Formato: secciones por continente (America del Sur, Europa, Asia)
     * Cada línea de datos: NUM CODIGO CIUDAD PAIS ABBREV GMT CAPACIDAD ...
     */
    private static final Pattern AEROPUERTO_LINE_PATTERN = Pattern.compile(
            "^\\s*\\d+\\s+([A-Za-z]{4})\\s+(.+?)\\s+([a-z]{2,4})\\s+([+-]?\\d+)\\s+(\\d+).*"
    );

    public static List<Aeropuerto> cargarAeropuertosDesdeArchivo(String texto) {
        List<Aeropuerto> lista = new ArrayList<>();
        String continenteActual = null;
        
        for (String linea : texto.split("\\n")) {
            linea = linea.trim();
            if (linea.isEmpty() || linea.startsWith("*")) continue;
            
            // Detectar cambio de sección por continente
            if (linea.contains("America del Sur")) {
                continenteActual = "SA";
                continue;
            } else if (linea.contains("Europa")) {
                continenteActual = "EU";
                continue;
            } else if (linea.contains("Asia")) {
                continenteActual = "AS";
                continue;
            }
            
            // Saltar línea de encabezado y comentarios
            if ((linea.contains("GMT") && linea.contains("CAPACIDAD")) || linea.contains("PDDS")) continue;
            
            // Intentar parsear como aeropuerto
            if (continenteActual != null) {
                Aeropuerto a = parsearLineaAeropuerto(linea, continenteActual);
                if (a != null) {
                    lista.add(a);
                    System.out.println("[DEBUG] Parseado aeropuerto: " + a.getCodigo() + " - " + a.getCiudad());
                } else {
                    System.out.println("[DEBUG] No se pudo parsear línea: " + linea);
                }
            }
        }
        
        return lista;
    }

    private static String leerTexto(Path archivo) throws IOException {
        byte[] bytes = Files.readAllBytes(archivo);
        if (bytes.length >= 2) {
            if (bytes[0] == (byte)0xFF && bytes[1] == (byte)0xFE) {
                return new String(bytes, StandardCharsets.UTF_16LE);
            }
            if (bytes[0] == (byte)0xFE && bytes[1] == (byte)0xFF) {
                return new String(bytes, StandardCharsets.UTF_16BE);
            }
        }
        if (bytes.length >= 3 && bytes[0] == (byte)0xEF && bytes[1] == (byte)0xBB && bytes[2] == (byte)0xBF) {
            return new String(bytes, StandardCharsets.UTF_8);
        }
        return new String(bytes, StandardCharsets.UTF_8);
    }

    /**
     * Parsea una línea individual de aeropuerto.
     * Formato: NUM CODIGO CIUDAD PAIS ABBREV GMT CAPACIDAD ...
     * Ejemplo: 01   SKBO   Bogota              Colombia        bogo    -5     430     Latitude: ...
     */
    private static Aeropuerto parsearLineaAeropuerto(String linea, String continente) {
        try {
            linea = linea.replace("\uFEFF", "").replace("\u00A0", " ").trim();
            Matcher matcher = AEROPUERTO_LINE_PATTERN.matcher(linea);
            if (!matcher.matches()) return null;

            String codigo = matcher.group(1).toUpperCase(Locale.ROOT).trim();
            if (codigo.length() != 4) return null;

            String ciudadPais = matcher.group(2).replace("\u00A0", " ").trim();
            String[] partesCiudadPais = ciudadPais.split("\\s{2,}");
            String ciudad = partesCiudadPais.length > 0 ? partesCiudadPais[0].trim() : "";
            String pais = partesCiudadPais.length > 1 ? partesCiudadPais[1].trim() : "";

            if (ciudad.isEmpty() || pais.isEmpty()) {
                return null;
            }

            int gmtOffset = Integer.parseInt(matcher.group(4));
            int capacidad = Integer.parseInt(matcher.group(5));
            int gmtMinutos = gmtOffset * 60;
            return new Aeropuerto(codigo, ciudad, pais, continente, gmtMinutos, capacidad);
        } catch (Exception e) {
            System.err.println("Error parseando línea de aeropuerto: " + linea);
            return null;
        }
    }
 
    // =========================================================================
    //  DEMO: crea archivos de ejemplo si no existen
    // =========================================================================
 
    public static void crearArchivosDemoSiNoExisten(String carpeta) throws IOException {
        Path raiz = Paths.get(carpeta);
        Files.createDirectories(raiz);
        Path enviosDir = raiz.resolve("envios");
        Files.createDirectories(enviosDir);
 
        Path vPath = raiz.resolve("vuelos.txt");
        if (!Files.exists(vPath)) {
            Files.write(vPath, ("# Plan de vuelos Tasf.B2B – ORIG-DEST-HH:MM-HH:MM-CCCC\n" +
                    "SKBO-SEQM-03:34-04:21-0300\nSEQM-SKBO-04:29-05:16-0340\n" +
                    "SKBO-SEQM-14:22-15:09-0320\nSEQM-SKBO-08:05-08:52-0320\n" +
                    "SKBO-SEQM-19:01-19:48-0340\nSEQM-SKBO-19:55-20:42-0360\n" +
                    "SKBO-SVMI-07:24-09:47-0300\nSVMI-SKBO-06:33-06:56-0340\n" +
                    "SKBO-SVMI-13:56-16:19-0360\nSVMI-SKBO-14:35-14:58-0340\n" +
                    "SKBO-SVMI-19:18-21:41-0360\nSVMI-SKBO-21:52-22:15-0360\n" +
                    "SKBO-SBBR-06:23-12:58-0320\nSBBR-SKBO-03:02-05:37-0320\n" +
                    "SKBO-SBBR-08:21-14:56-0300\nSBBR-SKBO-15:53-18:28-0360\n" +
                    "SKBO-SBBR-20:22-02:57-0360\nSBBR-SKBO-21:57-00:32-0360\n" +
                    "SKBO-SPIM-01:58-04:14-0340\nSPIM-SKBO-04:35-06:51-0340\n" +
                    "SKBO-SPIM-08:46-11:02-0300\nSPIM-SKBO-08:02-10:18-0300\n" +
                    "SKBO-SPIM-22:45-01:01-0340\nSPIM-SKBO-18:09-20:25-0340\n")
                    .getBytes());
            System.out.println("[Demo] Creado: " + vPath);
        }

        Path aPath = raiz.resolve("aeropuertos.txt");
        if (!Files.exists(aPath)) {
            Files.write(aPath, ("PDDS 26-1 (basado en 2026.1)  20260404\n" +
                    "***********************************************************************************************************************\n" +
                    "       America del Sur.\n" +
                    "       GMT  CAPACIDAD\n" +
                    "01   SKBO   Bogota              Colombia        bogo    -5     430\n" +
                    "02   SEQM   Quito               Ecuador         quit    -5     410\n" +
                    "03   SVMI   Caracas             Venezuela       cara    -4     400\n" +
                    "04   SBBR   Brasilia            Brasil          bras    -3     480\n" +
                    "05   SPIM   Lima                Perú            lima    -5     440\n" +
                    "06   SLLP   La Paz              Bolivia         lapa    -4     420\n" +
                    "07   SCEL   Santiago de Chile   Chile           sant    -3     460\n" +
                    "08   SABE   Buenos Aires        Argentina       buen    -3     460\n" +
                    "09   SGAS   Asunción            Paraguay        asun    -4     400\n" +
                    "10   SUAA   Motenvideo          Uruguay         mont    -3     400\n" +
                    "\n" +
                    "       Europa\n" +
                    "11   LATI   Tirana              Albania         tira    +2     410\n" +
                    "12   EDDI   Berlin              Alemania        berl    +2     480\n" +
                    "13   LOWW   Viena               Austria         vien    +2     430\n" +
                    "14   EBCI   Bruselas            Belgica         brus    +2     440\n" +
                    "15   UMMS   Minsk               Bielorrusia     mins    +3     400\n" +
                    "16   LBSF   Sofia               Bulgaria        sofi    +3     400\n" +
                    "17   LKPR   Praga               Checa           prag    +2     400\n" +
                    "18   LDZA   Zagreb              Croacia         zagr    +2     420\n" +
                    "19   EKCH   Copenhague          Dinamarca       cope    +2     480\n" +
                    "20   EHAM   Amsterdam           Holanda         amst    +2     480\n" +
                    "\n" +
                    "       Asia\n" +
                    "21   VIDP   Delhi               India           delh    +5     480\n" +
                    "22   OSDI   Damasco             Siria           dama    +3     400\n" +
                    "23   OERK   Riad                Arabia Saudita  riad    +3     420\n" +
                    "24   OMDB   Dubai               Emiratos A.U    emir    +4     420\n" +
                    "25   OAKB   Kabul               Afganistan      kabu    +4     480\n" +
                    "26   OOMS   Mascate             Oman            masc    +4     460\n" +
                    "27   OYSN   Sana                Yemen           sana    +3     420\n" +
                    "28   OPKC   Karachi             Pakistan        kara    +5     410\n" +
                    "29   UBBB   Baku                Azerbaiyan      baku    +2     400\n" +
                    "30   OJAI   Aman                Jordania        aman    +3     400\n")
                    .getBytes());
            System.out.println("[Demo] Creado: " + aPath);
        }
 
        Path ePath = enviosDir.resolve("_envios_SKBO.txt");
        if (!Files.exists(ePath)) {
            Files.write(ePath, ("000000001-20260102-01-22-SBBR-004-0025872\n" +
                    "000000002-20260102-02-42-EDDI-003-0027637\n" +
                    "000000003-20260102-04-03-OERK-003-0003163\n" +
                    "000000004-20260102-05-25-VIDP-003-0020245\n" +
                    "000000005-20260102-06-42-SBBR-003-0008317\n" +
                    "000000006-20260102-08-00-OPKC-003-0004776\n" +
                    "000000007-20260102-09-22-SVMI-003-0026742\n" +
                    "000000008-20260102-10-44-UMMS-001-0003833\n" +
                    "000000009-20260103-00-54-LDZA-002-0032428\n" +
                    "000000010-20260103-01-41-SEQM-002-0000792\n" +
                    "000000011-20260103-02-33-SUAA-002-0011290\n" +
                    "000000012-20260103-03-16-EBCI-001-0016435\n" +
                    "000000013-20260103-04-06-SBBR-001-0031430\n" +
                    "000000014-20260103-04-53-EKCH-001-0020563\n" +
                    "000000015-20260103-05-40-OERK-001-0002139\n" +
                    "000000016-20260103-06-24-SUAA-001-0007658\n" +
                    "000000017-20260103-07-19-SABE-001-0030513\n" +
                    "000000018-20260103-08-05-UMMS-001-0018369\n" +
                    "000000019-20260103-08-48-SLLP-001-0022821\n" +
                    "000000020-20260103-09-36-VIDP-001-0005126\n" +
                    "000000021-20260103-10-27-SABE-001-0006108\n" +
                    "000000022-20260103-11-14-SBBR-001-0022048\n" +
                    "000000023-20260103-12-05-SEQM-001-0007738\n")
                    .getBytes());
            System.out.println("[Demo] Creado: " + ePath);
        }
    }
 
    // =========================================================================
    //  UTILIDADES
    // =========================================================================
 
    /** Dias transcurridos desde 2026-01-02 (dia base = 0 de la simulacion). */
    public static int diasDesde20260102(int anio, int mes, int dia) {
        int base  = 2026 * 365 + 0 * 30 + 2;  // aprox. 2026-01-02
        int fecha = anio * 365 + (mes - 1) * 30 + dia;
        return fecha - base;
    }
 
    public static String getContinente(String icao) {
        return CONTINENTE_MAP.getOrDefault(icao, "?");
    }
 
    // =========================================================================
    //  DTO de retorno
    // =========================================================================
 
    public static class CargaCompleta {
        public final Map<String, Aeropuerto> aeropuertos;
        public final List<Vuelo>             vuelos;
        public final List<Envio>             envios;
 
        public CargaCompleta(Map<String, Aeropuerto> a, List<Vuelo> v, List<Envio> e) {
            this.aeropuertos = a; this.vuelos = v; this.envios = e;
        }
    }
}