package model;

import java.util.concurrent.atomic.AtomicInteger;
 
/**
 * Representa un vuelo programado entre dos aeropuertos.
 * Los tiempos se manejan en minutos desde medianoche UTC del día de simulación.
 */
public class Vuelo {
    private static int contadorId = 1;
 
    private final int    id;
    private final String origen;
    private final String destino;
    private final int    salidaUTC;   // minutos desde medianoche UTC
    private final int    llegadaUTC;  // minutos desde medianoche UTC
    private final int    capacidadMax;
 
    // Maletas ya asignadas (reservadas) a este vuelo
    private final AtomicInteger maletasAsignadas;
 
    public Vuelo(String origen, String destino, int salidaUTC, int llegadaUTC, int capacidadMax) {
        this.id = contadorId++;
        this.origen = origen;
        this.destino = destino;
        this.salidaUTC = salidaUTC;
        this.llegadaUTC = llegadaUTC;
        this.capacidadMax = capacidadMax;
        this.maletasAsignadas = new AtomicInteger(0);
    }
 
    // ---- Gestión de capacidad ------------------------------------------------
 
    /**
     * Intenta reservar {@code cantidad} plazas en el vuelo. Thread-safe.
     * @return true si hay espacio suficiente y se pudo reservar.
     */
    public boolean reservarPlazas(int cantidad) {
        while (true) {
            int actual = maletasAsignadas.get();
            int nuevo  = actual + cantidad;
            if (nuevo > capacidadMax) return false;
            if (maletasAsignadas.compareAndSet(actual, nuevo)) return true;
        }
    }
 
    /** Libera plazas previamente reservadas. */
    public void liberarPlazas(int cantidad) {
        maletasAsignadas.addAndGet(-cantidad);
    }
 
    public int getPlazasDisponibles() {
        return capacidadMax - maletasAsignadas.get();
    }
 
    public int getMaletasAsignadas() {
        return maletasAsignadas.get();
    }
 
    // ---- Getters -------------------------------------------------------------
 
    public int    getId()          { return id; }
    public String getOrigen()      { return origen; }
    public String getDestino()     { return destino; }
    public int    getSalidaUTC()   { return salidaUTC; }
    public int    getLlegadaUTC()  { return llegadaUTC; }
    public int    getCapacidadMax(){ return capacidadMax; }
 
    /** ¿El vuelo parte después (o igual) de {@code minuto} con al menos {@code cant} plazas? */
    public boolean disponibleDesde(int minuto, int cant) {
        return salidaUTC >= minuto && getPlazasDisponibles() >= cant;
    }
 
    @Override
    public String toString() {
        return String.format("V%03d %s->%s sal=%s lle=%s cap=%d/%d",
                id, origen, destino,
                minutosAHora(salidaUTC), minutosAHora(llegadaUTC),
                maletasAsignadas.get(), capacidadMax);
    }
 
    public static String minutosAHora(int minutos) {
        int d = minutos / 1440;
        int r = minutos % 1440;
        return String.format("D%d %02d:%02d", d + 1, r / 60, r % 60);
    }
 
    public static void resetContador() { contadorId = 1; }
}