package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
 
/**
 * Ruta asignada a un envío: secuencia de vuelos que llevan las maletas
 * desde el aeropuerto origen hasta el destino.
 *
 * Restricciones validadas:
 *  - Cada vuelo parte ≥ llegada del anterior + 10 min (conexión mínima).
 *  - El primer vuelo parte ≥ registroEnvío + 10 min.
 *  - Ningún aeropuerto se visita dos veces.
 *  - La llegada al destino final ≤ límite de entrega.
 */
public class Ruta {
 
    private final Envio       envio;
    private final List<Vuelo> vuelos;
 
    // Minuto UTC en que las maletas llegan al destino final
    private int llegadaFinalUTC;
    // true si la ruta cumple el plazo
    private boolean aTiempo;
 
    public Ruta(Envio envio, List<Vuelo> vuelos) {
        this.envio  = envio;
        this.vuelos = new ArrayList<>(vuelos);
        recalcular();
    }
 
    /** Ruta vacía (sin vuelos asignados). */
    public Ruta(Envio envio) {
        this.envio  = envio;
        this.vuelos = new ArrayList<>();
        this.llegadaFinalUTC = Integer.MAX_VALUE;
        this.aTiempo = false;
    }
 
    // ---- Validación y cálculo ------------------------------------------------
 
    /**
     * Valida la secuencia de vuelos y recalcula {@code llegadaFinalUTC}.
     * Si la secuencia es inválida, marca la ruta como no-a-tiempo.
     */
    public void recalcular() {
        if (vuelos.isEmpty()) {
            llegadaFinalUTC = Integer.MAX_VALUE;
            aTiempo = false;
            return;
        }
 
        List<String> visitados = new ArrayList<>();
        visitados.add(envio.getAeropuertoOrigen());
 
        int tiempoDisponible = envio.getPrimeroSalidaUTC(); // t_registro + 10
        Vuelo anterior = null;
 
        for (Vuelo v : vuelos) {
            // Conexión mínima: si hay vuelo anterior, esperar +10 desde llegada anterior
            if (anterior != null) {
                tiempoDisponible = anterior.getLlegadaUTC() + 10;
            }
 
            // El vuelo debe partir desde el aeropuerto correcto
            String esperado = (anterior == null) ? envio.getAeropuertoOrigen() : anterior.getDestino();
            if (!v.getOrigen().equals(esperado)) {
                llegadaFinalUTC = Integer.MAX_VALUE;
                aTiempo = false;
                return;
            }
 
            // El vuelo debe salir después de que las maletas estén listas
            if (v.getSalidaUTC() < tiempoDisponible) {
                llegadaFinalUTC = Integer.MAX_VALUE;
                aTiempo = false;
                return;
            }
 
            // No repetir aeropuertos
            if (visitados.contains(v.getDestino())) {
                llegadaFinalUTC = Integer.MAX_VALUE;
                aTiempo = false;
                return;
            }
 
            visitados.add(v.getDestino());
            anterior = v;
        }
 
        // El último destino debe ser el aeropuerto destino del envío
        if (anterior == null || !anterior.getDestino().equals(envio.getAeropuertoDestino())) {
            llegadaFinalUTC = Integer.MAX_VALUE;
            aTiempo = false;
            return;
        }
 
        llegadaFinalUTC = anterior.getLlegadaUTC();
        aTiempo = llegadaFinalUTC <= envio.getLimiteEntregaUTC();
    }
 
    // ---- Getters -------------------------------------------------------------
 
    public Envio        getEnvio()           { return envio; }
    public List<Vuelo>  getVuelos()          { return Collections.unmodifiableList(vuelos); }
    public int          getLlegadaFinalUTC() { return llegadaFinalUTC; }
    public boolean      isATiempo()          { return aTiempo; }
    public boolean      isValida()           { return llegadaFinalUTC < Integer.MAX_VALUE; }
 
    /** Tiempo de holgura: cuántos minutos sobran antes del límite (negativo = tarde). */
    public int holgura() {
        return envio.getLimiteEntregaUTC() - llegadaFinalUTC;
    }
 
    @Override
    public String toString() {
        if (vuelos.isEmpty()) return String.format("[%s] SIN RUTA", envio.getId());
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("[%s] %s → ", envio.getId(), envio.getAeropuertoOrigen()));
        for (Vuelo v : vuelos) {
            sb.append(String.format("%s(V%03d,sal=%s) → ",
                    v.getDestino(), v.getId(), Vuelo.minutosAHora(v.getSalidaUTC())));
        }
        sb.append(String.format("llegada=%s límite=%s %s",
                Vuelo.minutosAHora(llegadaFinalUTC),
                Vuelo.minutosAHora(envio.getLimiteEntregaUTC()),
                aTiempo ? "✓" : "✗"));
        return sb.toString();
    }
}