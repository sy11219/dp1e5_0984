package model;

import java.util.concurrent.atomic.AtomicInteger;
 
/**
 * Representa un aeropuerto con sus atributos y capacidad de almacenamiento.
 */
public class Aeropuerto {
    private final String codigo;
    private final String ciudad;
    private final String pais;
    private final String continente; // "AS" = America Sur, "EU" = Europa, "AS_IA" = Asia
    private final int gmtOffset;     // en minutos (ej: -5h = -300, +2h = +120)
    private final int capacidadMaxima;
 
    // Ocupación actual en el aeropuerto (reservada = comprometida + física)
    private final AtomicInteger ocupacionReservada;
 
    public Aeropuerto(String codigo, String ciudad, String pais, String continente,
                      int gmtOffsetMinutes, int capacidadMaxima) {
        this.codigo = codigo;
        this.ciudad = ciudad;
        this.pais = pais;
        this.continente = continente;
        this.gmtOffset = gmtOffsetMinutes;
        this.capacidadMaxima = capacidadMaxima;
        this.ocupacionReservada = new AtomicInteger(0);
    }
 
    // ---- Gestión de capacidad ------------------------------------------------
 
    /**
     * Intenta reservar {@code cantidad} plazas. Thread-safe (CAS loop).
     * @return true si se pudo reservar (hay espacio).
     */
    public boolean reservarEspacio(int cantidad) {
        while (true) {
            int actual = ocupacionReservada.get();
            int nuevo = actual + cantidad;
            if (nuevo > capacidadMaxima) return false;
            if (ocupacionReservada.compareAndSet(actual, nuevo)) return true;
        }
    }
 
    /** Libera plazas previamente reservadas. */
    public void liberarEspacio(int cantidad) {
        ocupacionReservada.addAndGet(-cantidad);
    }
 
    /** Espacio disponible (sin reservas pendientes). */
    public int espacioDisponible() {
        return capacidadMaxima - ocupacionReservada.get();
    }
 
    public int getOcupacionReservada() {
        return ocupacionReservada.get();
    }
 
    // ---- Getters -------------------------------------------------------------
 
    public String getCodigo()         { return codigo; }
    public String getCiudad()         { return ciudad; }
    public String getPais()           { return pais; }
    public String getContinente()     { return continente; }
    public int    getGmtOffset()      { return gmtOffset; }
    public int    getCapacidadMaxima(){ return capacidadMaxima; }
 
    @Override
    public String toString() {
        return String.format("%s (%s, %s) cap=%d ocu=%d",
                codigo, ciudad, pais, capacidadMaxima, ocupacionReservada.get());
    }
}