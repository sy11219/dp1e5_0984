package model;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
 
/**
 * Representa un envío de maletas registrado en un aeropuerto origen.
 * Formato del archivo: id-aaaammdd-hh-mm-dest-###-IdCliente
 */
public class Envio {
 
    public enum Estado { PENDIENTE, PLANIFICADO, EN_TRANSITO, ENTREGADO, ATRASADO }
 
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyyMMdd");
 
    private final String id;
    private final String aeropuertoOrigen;   // Código ICAO (del archivo que lo contiene)
    private final int    fechaHoraRegistroUTC; // Minutos UTC desde t=0 de simulación
    private final String aeropuertoDestino;
    private final int    cantidadMaletas;
    private final String idCliente;
    private final int    limiteEntregaUTC;    // t_registro + 720 (mismo cont.) o +1440
 
    private Estado estado;
 
    /**
     * @param id                  Identificador del envío
     * @param aeropuertoOrigen    Código ICAO del aeropuerto origen
     * @param registroUTC         Minutos UTC desde t=0 cuando se registra el envío
     * @param aeropuertoDestino   Código ICAO destino
     * @param cantidadMaletas     Cantidad de maletas
     * @param idCliente           ID del cliente
     * @param mismoContienente    true → límite 12h (720 min), false → 24h (1440 min)
     */
    public Envio(String id, String aeropuertoOrigen, int registroUTC,
                 String aeropuertoDestino, int cantidadMaletas,
                 String idCliente, boolean mismoContienente) {
        this.id = id;
        this.aeropuertoOrigen = aeropuertoOrigen;
        this.fechaHoraRegistroUTC = registroUTC;
        this.aeropuertoDestino = aeropuertoDestino;
        this.cantidadMaletas = cantidadMaletas;
        this.idCliente = idCliente;
        this.limiteEntregaUTC = registroUTC + (mismoContienente ? 720 : 1440);
        this.estado = Estado.PENDIENTE;
    }
 
    // ---- Getters -------------------------------------------------------------
 
    public String getId()                   { return id; }
    public String getAeropuertoOrigen()     { return aeropuertoOrigen; }
    public int    getRegistroUTC()          { return fechaHoraRegistroUTC; }
    public String getAeropuertoDestino()    { return aeropuertoDestino; }
    public int    getCantidadMaletas()      { return cantidadMaletas; }
    public String getIdCliente()            { return idCliente; }
    public int    getLimiteEntregaUTC()     { return limiteEntregaUTC; }
    public Estado getEstado()               { return estado; }
    public void   setEstado(Estado estado)  { this.estado = estado; }
 
    /** Primer minuto en que las maletas pueden salir del aeropuerto origen (registro + 10 min). */
    public int getPrimeroSalidaUTC() { return fechaHoraRegistroUTC + 10; }
 
    @Override
    public String toString() {
        return String.format("Envio[%s] %s→%s %dmal lim=%s [%s]",
                id, aeropuertoOrigen, aeropuertoDestino, cantidadMaletas,
                Vuelo.minutosAHora(limiteEntregaUTC), estado);
    }
}