package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
 
/**
 * Solución completa: una ruta por cada envío.
 * Calcula el fitness (objetivo a maximizar: envíos entregados a tiempo).
 */
public class Solucion {
 
    private final List<Ruta> rutas;
 
    // Fitness: número de maletas entregadas a tiempo (mayor = mejor)
    private int maletasATiempo;
    private int enviosATiempo;
    private int totalMaletas;
    private int totalEnvios;
 
    public Solucion(List<Ruta> rutas) {
        this.rutas = new ArrayList<>(rutas);
        calcularFitness();
    }
 
    // ---- Fitness -------------------------------------------------------------
 
    private void calcularFitness() {
        maletasATiempo = 0;
        enviosATiempo  = 0;
        totalMaletas   = 0;
        totalEnvios    = rutas.size();
 
        for (Ruta r : rutas) {
            int cant = r.getEnvio().getCantidadMaletas();
            totalMaletas += cant;
            if (r.isATiempo()) {
                maletasATiempo += cant;
                enviosATiempo++;
            }
        }
    }
 
    /**
     * Fitness principal: maletas a tiempo.
     * Secundario: envíos a tiempo (desempate).
     * Se representa como un doble para comparación fácil.
     */
    public double getFitness() {
        // Ponderación: maletas (peso mayor) + envíos (desempate)
        return maletasATiempo * 1000.0 + enviosATiempo;
    }
 
    // ---- Deep copy -----------------------------------------------------------
 
    /**
     * Crea una copia profunda de la solución.
     * IMPORTANTE: no copia las reservas de vuelos/aeropuertos.
     */
    public Solucion copiar() {
        List<Ruta> copia = new ArrayList<>();
        for (Ruta r : rutas) {
            // Crea nueva ruta con los mismos vuelos (referencias)
            copia.add(new Ruta(r.getEnvio(), new ArrayList<>(r.getVuelos())));
        }
        return new Solucion(copia);
    }
 
    // ---- Getters -------------------------------------------------------------
 
    public List<Ruta> getRutas()          { return Collections.unmodifiableList(rutas); }
    public int getMaletasATiempo()        { return maletasATiempo; }
    public int getEnviosATiempo()         { return enviosATiempo; }
    public int getTotalMaletas()          { return totalMaletas; }
    public int getTotalEnvios()           { return totalEnvios; }
 
    public double getPorcentajeATiempo() {
        return totalMaletas == 0 ? 0.0 : (100.0 * maletasATiempo / totalMaletas);
    }
 
    @Override
    public String toString() {
        return String.format("Solución: %d/%d envíos a tiempo | %d/%d maletas (%.1f%%)",
                enviosATiempo, totalEnvios, maletasATiempo, totalMaletas, getPorcentajeATiempo());
    }
}