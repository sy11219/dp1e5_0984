import algorithm.Planificador;
import algorithm.SimulatedAnnealing;
import data.DataLoader;
import data.DataLoader.CargaCompleta;
import model.*;
import report.ReporteResultados;
 
import java.util.*;
 
/**
 * ================================================================
 *  MAIN – Planificador de Rutas Tasf.B2B
 *  Algoritmo: Simulated Annealing
 * ================================================================
 *
 * COMPILAR:
 *   javac -encoding UTF-8 -d out src/model/*.java src/data/*.java
 *         src/algorithm/*.java src/report/*.java src/Main.java
 *
 * EJECUTAR:
 *   java -cp out Main
 *
 * ESTRUCTURA DE CARPETA DE DATOS (/src/datos/ automática):
 *   aeropuertos.txt
 *   vuelos.txt
 *   envios/
 *     _envios_SKBO_.txt
 *     _envios_SEQM_.txt
 *     ... (un archivo por aeropuerto origen)
 */
public class Main {
 
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
 
        System.out.println("╔══════════════════════════════════════════════════════╗");
        System.out.println("║   TASF.B2B – Planificador de Rutas (Simulated Ann.)  ║");
        System.out.println("╚══════════════════════════════════════════════════════╝");
        System.out.println();
 
        // ---- 1. Carpeta de datos --------------------------------------------
        String carpeta = "src/datos";
        System.out.println("Carpeta de datos: " + carpeta);
 
        // Crear archivos de demo si la carpeta no tiene datos
        try {
            DataLoader.crearArchivosDemoSiNoExisten(carpeta);
        } catch (Exception e) {
            System.err.println("Advertencia al crear archivos demo: " + e.getMessage());
        }
 
        // ---- 2. Parámetros de simulación ------------------------------------
        System.out.print("Numero de dias a simular [2]: ");
        String diasStr = sc.nextLine().trim();
        int diasSimulacion = diasStr.isEmpty() ? 2 : Integer.parseInt(diasStr);
 
        // ---- 3. Parámetros del SA ------------------------------------------
        System.out.println("\n-- Parametros Simulated Annealing (Enter = usar default) --");
 
        System.out.print("Temperatura inicial T0 [5000]: ");
        String t0s = sc.nextLine().trim();
        double T0 = t0s.isEmpty() ? 5000.0 : Double.parseDouble(t0s);
 
        System.out.print("Factor de enfriamiento alpha [0.995]: ");
        String alphas = sc.nextLine().trim();
        double alpha = alphas.isEmpty() ? 0.995 : Double.parseDouble(alphas);
 
        System.out.print("Iteraciones por temperatura [50]: ");
        String iters = sc.nextLine().trim();
        int iterPorTemp = iters.isEmpty() ? 50 : Integer.parseInt(iters);
 
        // ---- 4. Semáforo ---------------------------------------------------
        System.out.println("\n-- Umbrales de semaforo (% ocupacion aeropuerto) --");
        System.out.print("Umbral VERDE  (por debajo = ok)  [0.60]: ");
        String uvs = sc.nextLine().trim();
        double umbralVerde = uvs.isEmpty() ? 0.60 : Double.parseDouble(uvs);
 
        System.out.print("Umbral AMBAR  (por encima = rojo)[0.85]: ");
        String uas = sc.nextLine().trim();
        double umbralAmbar = uas.isEmpty() ? 0.85 : Double.parseDouble(uas);
 
        System.out.println();
 
        // ---- 5. Cargar datos -----------------------------------------------
        CargaCompleta datos;
        try {
            datos = DataLoader.cargarDesde(carpeta, diasSimulacion);
        } catch (Exception e) {
            System.err.println("ERROR cargando datos: " + e.getMessage());
            return;
        }
 
        if (datos.envios.isEmpty()) {
            System.out.println("No se encontraron envios. Verifique que existen archivos _envios_*.txt en: " + carpeta);
            return;
        }
 
        // ---- 6. Ejecutar SA ------------------------------------------------
        Planificador planificador = new Planificador(datos.aeropuertos, datos.vuelos);
 
        SimulatedAnnealing sa = new SimulatedAnnealing(planificador)
                .setTemperaturaInicial(T0)
                .setAlpha(alpha)
                .setIteracionesPorTemp(iterPorTemp)
                .setMaxIteraciones(300_000)
                .setMaxRutasAlternativas(10);
 
        Solucion mejor = sa.ejecutar(datos.envios);
 
        // ---- 7. Reporte ----------------------------------------------------
        ReporteResultados reporte = new ReporteResultados(umbralVerde, umbralAmbar);
        reporte.imprimirReporte(mejor, datos.aeropuertos);
 
        // ---- 8. Planes de viaje detallados (primeros 5) --------------------
        System.out.println("\nPLANES DE VIAJE – primeros 5 envios:");
        mejor.getRutas().stream().limit(5).forEach(reporte::imprimirPlanViaje);
 
        // ---- 9. Consulta interactiva de monitoreo ---------------------------
        System.out.print("\n¿Consultar monitoreo de un envio especifico? (s/n): ");
        String resp = sc.nextLine().trim().toLowerCase();
        while (resp.equals("s")) {
            System.out.print("ID del envio: ");
            String buscar = sc.nextLine().trim();
            mejor.getRutas().stream()
                    .filter(r -> r.getEnvio().getId().equals(buscar))
                    .findFirst()
                    .ifPresentOrElse(
                            reporte::imprimirPlanViaje,
                            () -> System.out.println("Envio no encontrado: " + buscar));
            System.out.print("¿Consultar otro? (s/n): ");
            resp = sc.nextLine().trim().toLowerCase();
        }
 
        System.out.println("\nFin. Gracias por usar Tasf.B2B Planificador.");
    }
}
