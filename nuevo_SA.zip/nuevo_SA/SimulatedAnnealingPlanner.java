package com.tasfb2b.planner;

import com.tasfb2b.model.Airport;
import com.tasfb2b.model.Flight;
import com.tasfb2b.model.Route;
import com.tasfb2b.model.Shipment;
import com.tasfb2b.util.RouteFinder;

import java.util.*;

/**
 * Planificador de rutas de maletas usando Simulated Annealing (SA).
 *
 * ═══════════════════════════════════════════════════════════════════════
 * DESCRIPCIÓN DEL ALGORITMO
 * ═══════════════════════════════════════════════════════════════════════
 *
 * Simulated Annealing es una metaheurística inspirada en el proceso de
 * enfriamiento del metal. Permite escapar de óptimos locales aceptando
 * soluciones peores con cierta probabilidad que decrece con la "temperatura".
 *
 * En este contexto:
 * - SOLUCIÓN: Asignación de una ruta a cada envío (qué vuelos toma cada maleta)
 * - FUNCIÓN OBJETIVO: Minimizar retrasos totales + penalizar rutas sin solución
 * - VECINO: Cambiar la ruta de un envío al azar entre sus rutas candidatas
 * - TEMPERATURA: Controla la probabilidad de aceptar soluciones peores
 *
 * ═══════════════════════════════════════════════════════════════════════
 * RESTRICCIONES DEL PROBLEMA
 * ═══════════════════════════════════════════════════════════════════════
 *
 * 1. Capacidad de vuelos: Un vuelo no puede llevar más maletas de su límite.
 * 2. Capacidad de aeropuertos: Un aeropuerto no puede almacenar más maletas
 *    de su capacidad (considera llegadas y salidas en el tiempo).
 * 3. Plazos de entrega:
 *    - Mismo continente: 12 horas (720 min) desde solicitud
 *    - Distinto continente: 24 horas (1440 min) desde solicitud
 * 4. Tiempo de conexión: 10 minutos mínimos entre llegada y siguiente vuelo
 *    en aeropuertos intermedios.
 *
 * ═══════════════════════════════════════════════════════════════════════
 * PARÁMETROS DEL SA (ajustables)
 * ═══════════════════════════════════════════════════════════════════════
 *
 * - INITIAL_TEMPERATURE: Temperatura inicial (alta → acepta peores soluciones)
 * - COOLING_RATE: Factor de enfriamiento por iteración (0.99 → enfría lentamente)
 * - MIN_TEMPERATURE: Temperatura mínima (detiene el algoritmo)
 * - ITERATIONS_PER_TEMP: Iteraciones por nivel de temperatura
 */
public class SimulatedAnnealingPlanner {

    // ── Parámetros del SA ────────────────────────────────────────────────────
    private static final double INITIAL_TEMPERATURE   = 10000.0;
    private static final double COOLING_RATE          = 0.995;
    private static final double MIN_TEMPERATURE       = 0.1;
    private static final int    ITERATIONS_PER_TEMP   = 50;

    // Penalización por envío sin ruta posible (grande para forzar al SA a encontrar rutas)
    private static final int    PENALTY_NO_ROUTE      = 100_000;
    // Penalización adicional por cada minuto de retraso
    private static final int    PENALTY_PER_DELAY_MIN = 10;

    // ── Dependencias ──────────────────────────────────────────────────────────
    private final Map<String, Airport> airportMap;   // Código ICAO → Airport
    private final List<Flight>         flights;       // Todos los vuelos disponibles
    private final RouteFinder          routeFinder;   // Módulo de búsqueda de rutas candidatas
    private final Random               random;

    /**
     * Constructor del planificador.
     *
     * @param airports Lista de todos los aeropuertos
     * @param flights  Lista de todos los vuelos disponibles (todos los días)
     */
    public SimulatedAnnealingPlanner(List<Airport> airports, List<Flight> flights) {
        this.flights    = flights;
        this.routeFinder = new RouteFinder();
        this.random     = new Random(42); // Semilla fija para reproducibilidad

        // Construir mapa de aeropuertos por código ICAO
        this.airportMap = new HashMap<>();
        for (Airport a : airports) {
            airportMap.put(a.getCode(), a);
        }
    }

    /**
     * Ejecuta la planificación de rutas para todos los envíos.
     *
     * PROCESO PRINCIPAL:
     * 1. Para cada envío, genera rutas candidatas usando BFS (RouteFinder)
     * 2. Inicializa una solución tomando la mejor ruta candidata para cada envío
     * 3. Ejecuta el ciclo de Simulated Annealing para mejorar la solución
     * 4. Al final, aplica la mejor solución encontrada y registra los resultados
     *
     * @param shipments Lista de todos los envíos a planificar
     * @return Lista de envíos con sus rutas asignadas (modificados in-place)
     */
    public List<Shipment> plan(List<Shipment> shipments) {
        System.out.println("\n[SA Planner] Iniciando planificacion con Simulated Annealing...");
        System.out.printf("[SA Planner] Envios a planificar: %d | Vuelos disponibles: %d%n",
                shipments.size(), flights.size());

        // ── Paso 1: Generar rutas candidatas para cada envío ─────────────────
        System.out.println("[SA Planner] Generando rutas candidatas (BFS)...");
        Map<String, List<Route>> candidatesMap = new HashMap<>();
        int noRoutesCount = 0;

        for (Shipment s : shipments) {
            List<Route> candidates = routeFinder.findCandidateRoutes(
                    s.getOriginCode(), s.getDestCode(),
                    s.getRequestMinute(), s.getSuitcaseCount(),
                    flights, s.getShipmentId()
            );
            candidatesMap.put(s.getShipmentId(), candidates);

            if (candidates.isEmpty()) {
                noRoutesCount++;
                System.out.printf("  [AVISO] Sin rutas candidatas para envio %s (%s→%s)%n",
                        s.getShipmentId(), s.getOriginCode(), s.getDestCode());
            } else {
                System.out.printf("  Envio %s: %d rutas candidatas encontradas%n",
                        s.getShipmentId(), candidates.size());
            }
        }

        if (noRoutesCount > 0) {
            System.out.printf("[SA Planner] AVISO: %d envios sin rutas candidatas.%n", noRoutesCount);
        }

        // ── Paso 2: Solución inicial ──────────────────────────────────────────
        // Asignar la primera ruta candidata (más rápida) a cada envío
        int[] currentSolution = initializeSolution(shipments, candidatesMap);
        double currentCost    = evaluateSolution(shipments, candidatesMap, currentSolution);

        int[]  bestSolution   = Arrays.copyOf(currentSolution, currentSolution.length);
        double bestCost       = currentCost;

        System.out.printf("[SA Planner] Costo inicial: %.2f%n", currentCost);

        // ── Paso 3: Ciclo de Simulated Annealing ─────────────────────────────
        double temperature = INITIAL_TEMPERATURE;
        int    totalIter   = 0;
        int    improvements = 0;
        int    accepted    = 0;

        while (temperature > MIN_TEMPERATURE) {
            for (int iter = 0; iter < ITERATIONS_PER_TEMP; iter++) {
                totalIter++;

                // Generar una solución vecina: cambiar la ruta de un envío al azar
                int[] neighbor = generateNeighbor(currentSolution, shipments, candidatesMap);
                if (neighbor == null) continue;

                double neighborCost = evaluateSolution(shipments, candidatesMap, neighbor);
                double delta        = neighborCost - currentCost;

                // Criterio de aceptación SA:
                // Si la solución vecina es mejor (delta < 0), aceptar siempre.
                // Si es peor (delta > 0), aceptar con probabilidad e^(-delta/T).
                if (delta < 0 || random.nextDouble() < Math.exp(-delta / temperature)) {
                    currentSolution = neighbor;
                    currentCost     = neighborCost;
                    accepted++;

                    if (currentCost < bestCost) {
                        bestSolution = Arrays.copyOf(currentSolution, currentSolution.length);
                        bestCost     = currentCost;
                        improvements++;
                    }
                }
            }

            temperature *= COOLING_RATE;
        }

        System.out.printf("[SA Planner] SA completado: %d iteraciones | %d aceptadas | %d mejoras%n",
                totalIter, accepted, improvements);
        System.out.printf("[SA Planner] Costo final: %.2f%n", bestCost);

        // ── Paso 4: Aplicar la mejor solución encontrada ──────────────────────
        applySolution(shipments, candidatesMap, bestSolution);

        return shipments;
    }

    // ════════════════════════════════════════════════════════════════════════
    // MÉTODOS AUXILIARES DEL SA
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Inicializa la solución seleccionando la primera ruta candidata para cada envío.
     * Para envíos sin rutas, asigna -1 (sin ruta).
     *
     * @param shipments     Lista de envíos
     * @param candidatesMap Mapa de rutas candidatas por ID de envío
     * @return Array de índices de ruta seleccionada por envío (paralelo a shipments)
     */
    private int[] initializeSolution(List<Shipment> shipments,
                                      Map<String, List<Route>> candidatesMap) {
        int[] solution = new int[shipments.size()];
        for (int i = 0; i < shipments.size(); i++) {
            List<Route> candidates = candidatesMap.get(shipments.get(i).getShipmentId());
            solution[i] = (candidates != null && !candidates.isEmpty()) ? 0 : -1;
        }
        return solution;
    }

    /**
     * Evalúa el costo de una solución completa.
     *
     * Función objetivo (a MINIMIZAR):
     * Para cada envío:
     *   - Si no tiene ruta: +PENALTY_NO_ROUTE
     *   - Si tiene ruta y llega a tiempo: +0
     *   - Si tiene ruta y llega tarde: +PENALTY_PER_DELAY_MIN * minutos_de_retraso
     *
     * Adicionalmente, se penaliza si un vuelo supera su capacidad o un aeropuerto
     * supera la suya (restricciones hard, penalización muy alta).
     *
     * NOTA: Esta función hace una evaluación aproximada sin modificar el estado real
     * de vuelos/aeropuertos, para mantener el SA puro y reversible.
     *
     * @param shipments     Lista de envíos
     * @param candidatesMap Mapa de rutas candidatas
     * @param solution      Indices de rutas seleccionadas
     * @return Costo total (menor es mejor)
     */
    private double evaluateSolution(List<Shipment> shipments,
                                     Map<String, List<Route>> candidatesMap,
                                     int[] solution) {
        // Contadores de carga para vuelos en esta evaluación
        Map<String, Integer> flightLoad    = new HashMap<>();
        Map<String, Integer> airportLoad   = new HashMap<>();
        double totalCost = 0.0;

        for (int i = 0; i < shipments.size(); i++) {
            Shipment s = shipments.get(i);
            int routeIdx = solution[i];

            if (routeIdx == -1) {
                // Sin ruta posible
                totalCost += PENALTY_NO_ROUTE;
                continue;
            }

            List<Route> candidates = candidatesMap.get(s.getShipmentId());
            if (candidates == null || routeIdx >= candidates.size()) {
                totalCost += PENALTY_NO_ROUTE;
                continue;
            }

            Route route = candidates.get(routeIdx);
            int arrivalMinute = route.calculateArrivalMinute();

            // Calcular el plazo según continentes
            Airport origin = airportMap.get(s.getOriginCode());
            Airport dest   = airportMap.get(s.getDestCode());
            int deadlineMinutes = (origin != null && dest != null)
                    ? Shipment.getDeadlineMinutes(origin.getContinent(), dest.getContinent())
                    : 1440;
            int deadline = s.getRequestMinute() + deadlineMinutes;

            // Penalización por retraso
            if (arrivalMinute > deadline) {
                totalCost += (double)(arrivalMinute - deadline) * PENALTY_PER_DELAY_MIN;
            }

            // Verificar capacidad de vuelos en esta ruta
            for (Flight f : route.getFlights()) {
                int load = flightLoad.getOrDefault(f.getFlightId(), f.getAssignedLoad());
                load += s.getSuitcaseCount();
                if (load > f.getMaxCapacity()) {
                    // Sobrecarga de vuelo: penalización por maleta de exceso
                    totalCost += (load - f.getMaxCapacity()) * 500.0;
                }
                flightLoad.put(f.getFlightId(), load);
            }

            // Verificar capacidad del aeropuerto destino de cada vuelo
            for (Flight f : route.getFlights()) {
                String destAp = f.getDestCode();
                Airport ap = airportMap.get(destAp);
                if (ap == null) continue;
                int load = airportLoad.getOrDefault(destAp, ap.getCurrentLoad());
                load += s.getSuitcaseCount();
                if (load > ap.getMaxCapacity()) {
                    totalCost += (load - ap.getMaxCapacity()) * 1000.0;
                }
                // Las maletas salen del aeropuerto en el siguiente vuelo
                if (!f.getDestCode().equals(s.getDestCode())) {
                    airportLoad.put(destAp, load);
                }
            }
        }

        return totalCost;
    }

    /**
     * Genera una solución vecina cambiando la ruta de un envío seleccionado al azar.
     *
     * Estrategias de generación de vecinos (elegidas aleatoriamente):
     * - SWAP: Cambiar la ruta del envío i a otra de sus rutas candidatas
     * - SWAP_PAIR: Intercambiar las rutas entre dos envíos (si ambos tienen candidatas comunes)
     *
     * @param current       Solución actual (array de índices)
     * @param shipments     Lista de envíos
     * @param candidatesMap Mapa de rutas candidatas
     * @return Nueva solución vecina, o null si no se pudo generar
     */
    private int[] generateNeighbor(int[] current, List<Shipment> shipments,
                                    Map<String, List<Route>> candidatesMap) {
        int[] neighbor = Arrays.copyOf(current, current.length);

        // Elegir un envío al azar que tenga múltiples rutas candidatas
        int attempts = 0;
        while (attempts < 20) {
            int i = random.nextInt(shipments.size());
            Shipment s = shipments.get(i);
            List<Route> candidates = candidatesMap.get(s.getShipmentId());

            if (candidates != null && candidates.size() > 1) {
                // Cambiar a una ruta diferente al azar
                int newRouteIdx;
                do {
                    newRouteIdx = random.nextInt(candidates.size());
                } while (newRouteIdx == current[i]);

                neighbor[i] = newRouteIdx;
                return neighbor;
            }
            attempts++;
        }

        return null; // No se encontró un vecino válido
    }

    /**
     * Aplica la mejor solución encontrada por el SA a los envíos.
     *
     * Para cada envío, asigna la ruta seleccionada y llama a
     * shipment.setResult() con los parámetros de llegada y plazo.
     *
     * También actualiza la carga real de vuelos y aeropuertos.
     *
     * @param shipments     Lista de envíos
     * @param candidatesMap Mapa de rutas candidatas
     * @param solution      Indices de rutas seleccionadas (la mejor solución del SA)
     */
    private void applySolution(List<Shipment> shipments,
                                Map<String, List<Route>> candidatesMap,
                                int[] solution) {
        // Resetear cargas de vuelos para recalcular desde cero
        for (Flight f : flights) f.resetLoad();

        int onTimeCount = 0;
        int lateCount   = 0;
        int noRouteCount = 0;

        for (int i = 0; i < shipments.size(); i++) {
            Shipment s       = shipments.get(i);
            int routeIdx     = solution[i];

            if (routeIdx == -1) {
                noRouteCount++;
                System.out.printf("  [SIN RUTA] Envio %s (%s→%s) no tiene ruta posible%n",
                        s.getShipmentId(), s.getOriginCode(), s.getDestCode());
                continue;
            }

            List<Route> candidates = candidatesMap.get(s.getShipmentId());
            if (candidates == null || routeIdx >= candidates.size()) {
                noRouteCount++;
                continue;
            }

            Route route = candidates.get(routeIdx);

            // Asignar carga en los vuelos de esta ruta
            for (Flight f : route.getFlights()) {
                f.assignLoad(s.getSuitcaseCount());
            }

            // Calcular plazo según continentes
            Airport origin = airportMap.get(s.getOriginCode());
            Airport dest   = airportMap.get(s.getDestCode());
            int deadlineMinutes = (origin != null && dest != null)
                    ? Shipment.getDeadlineMinutes(origin.getContinent(), dest.getContinent())
                    : 1440;

            int arrivalMinute = route.calculateArrivalMinute();
            s.setResult(route, arrivalMinute, deadlineMinutes);

            if (s.isOnTime()) onTimeCount++;
            else              lateCount++;
        }

        System.out.printf("%n[SA Planner] Resultados finales:%n");
        System.out.printf("  A tiempo    : %d envios%n", onTimeCount);
        System.out.printf("  Con retraso : %d envios%n", lateCount);
        System.out.printf("  Sin ruta    : %d envios%n", noRouteCount);
        System.out.printf("  Total       : %d envios%n", shipments.size());
    }
}
