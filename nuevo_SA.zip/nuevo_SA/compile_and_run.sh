#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════
# compile_and_run.sh
# Script de compilación y ejecución del sistema TASF.B2B
#
# USO:
#   chmod +x compile_and_run.sh
#   ./compile_and_run.sh
#
# Requiere Java 8 o superior instalado.
# ═══════════════════════════════════════════════════════════════════════════

# Colores para salida (solo si la terminal los soporta)
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "=========================================================="
echo "  TASF.B2B - Compilación y Ejecución"
echo "=========================================================="

# Verificar Java
if ! command -v javac &> /dev/null; then
    echo -e "${RED}ERROR: javac no encontrado. Instale JDK 8 o superior.${NC}"
    exit 1
fi
JAVA_VER=$(java -version 2>&1 | head -n1)
echo "Java encontrado: $JAVA_VER"

# Crear directorio de salida de clases
mkdir -p out

# ── Compilar ──────────────────────────────────────────────────────────────
echo ""
echo ">> Compilando fuentes..."

SOURCES=$(find src/main/java -name "*.java")

javac -d out -sourcepath src/main/java $SOURCES

if [ $? -ne 0 ]; then
    echo -e "${RED}ERROR: Falló la compilación. Revise los errores arriba.${NC}"
    exit 1
fi

echo -e "${GREEN}>> Compilación exitosa.${NC}"

# ── Verificar estructura de datos ────────────────────────────────────────
echo ""
echo ">> Verificando estructura de datos..."

MISSING=0
if [ ! -f "data/aeropuertos.txt" ]; then
    echo -e "${RED}  FALTA: data/aeropuertos.txt${NC}"
    MISSING=1
fi
if [ ! -f "data/planes_vuelo.txt" ]; then
    echo -e "${RED}  FALTA: data/planes_vuelo.txt${NC}"
    MISSING=1
fi
if [ ! -d "data/envios" ]; then
    echo -e "${RED}  FALTA: directorio data/envios/${NC}"
    MISSING=1
else
    COUNT=$(ls data/envios/_envio*.txt 2>/dev/null | wc -l)
    if [ "$COUNT" -eq 0 ]; then
        echo -e "${YELLOW}  AVISO: No se encontraron archivos _envios_XXXX_.txt en data/envios/${NC}"
    else
        echo -e "${GREEN}  OK: $COUNT archivos de envios encontrados en data/envios/${NC}"
    fi
fi

if [ "$MISSING" -eq 1 ]; then
    echo -e "${YELLOW}  Algunos archivos de datos faltan. El programa puede fallar al cargar datos.${NC}"
fi

# ── Ejecutar ──────────────────────────────────────────────────────────────
echo ""
echo ">> Ejecutando TASF.B2B Planificador..."
echo "=========================================================="

java -cp out com.tasfb2b.Main

echo "=========================================================="
echo ">> Fin de ejecución."
